(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };

},{}],2:[function(require,module,exports){
const {Client} = require("iexjs")
const client = new Client({api_token: "pk_dd18fa4eab324fa0b7117e7be8c7677a", version: "v1"})
$(document).ready(function(){
  let symbol = window.config.xenSymbolConfig.toUpperCase()
  $('#preTickerText').text('$' + symbol)
  client.book(symbol).then((res) => {
    $("#TickerText").text("$" + parseFloat(res.quote.latestPrice).toFixed(2) + " USD")
  });
  setInterval(() => {
    client.book(symbol).then((res) => {
      $("#TickerText").text("$" + parseFloat(res.quote.latestPrice).toFixed(2) + " USD")
    });
  }, 300000);
});
},{"iexjs":3}],3:[function(require,module,exports){
(function (process,global){(function (){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.IEXJSException = ge;
exports.deepSSE = exports.daily = exports.cryptoSymbolsList = exports.cryptoSymbols = exports.cryptoQuotesSSE = exports.cryptoQuote = exports.cryptoPrice = exports.cryptoEventsSSE = exports.cryptoBookSSE = exports.cryptoBook = exports.creditcard = exports.create = exports.cpi = exports.convertFX = exports.companyTravelWallStreetHorizon = exports.company = exports.collections = exports.chart = exports.ceoCompensation = exports.cdnj = exports.cdj = exports.cashFlow = exports.capitalMarketsDayWallStreetHorizon = exports.cam1ExtractAlpha = exports.calendar = exports.buybacksWallStreetHorizon = exports.businessUpdatesWallStreetHorizon = exports.brent = exports.bookSSE = exports.book = exports.bonusIssue = exports.boardOfDirectorsMeetingWallStreetHorizon = exports.batch = exports.balanceSheet = exports.auctionSSE = exports.analystRecommendations = exports.analystDaysWallStreetHorizon = exports.advancedStats = exports.accountingQualityAndRiskMatrixAuditAnalytics = exports._timeseriesWrapper = exports._streamSSE = exports._strToList = exports._strOrDate = exports._strCommaSeparatedString = exports._runSSE = exports._requireSecret = exports._raiseIfNotStr = exports._quoteSymbols = exports._post = exports._get = exports._delete = exports._dateRange = exports._checkPeriodLast = exports._USAGE_TYPES = exports._URL_PREFIX_CLOUD_SANDBOX = exports._URL_PREFIX_CLOUD = exports._URL_PREFIX = exports._TIMEFRAME_DIVSPLIT = exports._TIMEFRAME_CHART = exports._STANDARD_TIME_FIELDS = exports._STANDARD_DATE_FIELDS = exports._SSE_URL_PREFIX_SANDBOX = exports._SSE_URL_PREFIX_ALL_SANDBOX = exports._SSE_URL_PREFIX_ALL = exports._SSE_URL_PREFIX = exports._SSE_DEEP_URL_PREFIX_SANDBOX = exports._SSE_DEEP_URL_PREFIX = exports._SIO_URL_PREFIX = exports._SIO_PORT = exports._LIST_OPTIONS = exports._KEY_STATS = exports._INDICATOR_RETURNS = exports._INDICATORS = exports._DATE_RANGES = exports._COLLECTION_TAGS = exports._BATCH_TYPES = exports.VERSION = exports.TRADINGSTATUS = exports.TRADES = exports.TRADEBREAK = exports.SYSTEMEVENT = exports.STOCKSUSNOUTP = exports.STOCKSUS5SECOND = exports.STOCKSUS1SECOND = exports.STOCKSUS1MINUTE = exports.STOCKSUS = exports.SSR = exports.SECURITYEVENT = exports.OPHALTSTATUS = exports.FOREX5SECOND = exports.FOREX1SECOND = exports.FOREX1MINUTE = exports.FOREX = exports.Client = exports.CRYPTOQUOTES = exports.CRYPTOEVENTS = exports.CRYPTOBOOK = exports.BOOK = exports.AUCTION = exports.ALL = void 0;
exports.latestFX = exports.lastSSE = exports.largestTrades = exports.languageMetricsOnCompanyFilingsDifferenceBrain = exports.languageMetricsOnCompanyFilingsDifferenceAllBrain = exports.languageMetricsOnCompanyFilingsBrain = exports.languageMetricsOnCompanyFilingsAllBrain = exports.keyStats = exports.kScoreKavout = exports.kScoreChinaKavout = exports.jet = exports.isinLookup = exports.iposWallStreetHorizon = exports.ipoUpcoming = exports.ipoToday = exports.intraday = exports.internationalSymbolsList = exports.internationalSymbols = exports.internationalExchanges = exports.institutionalOwnership = exports.institutionalMoney = exports.insiderTransactions = exports.insiderSummary = exports.insiderRoster = exports.initialClaims = exports.indpro = exports.indexChangesWallStreetHorizon = exports.incomeStatement = exports.iexTradingStatus = exports.iexTrades = exports.iexTradeBreak = exports.iexTops = exports.iexSystemEvent = exports.iexSymbolsList = exports.iexSymbols = exports.iexSsrStatus = exports.iexSecurityEvent = exports.iexOpHaltStatus = exports.iexOfficialPrice = exports.iexLast = exports.iexHist = exports.iexDeep = exports.iexBook = exports.iexAuction = exports.housing = exports.holidaysWallStreetHorizon = exports.holidays = exports.historicalFX = exports.heatoil = exports.generalConferenceWallStreetHorizon = exports.gdp = exports.gasreg = exports.gasprm = exports.gasmid = exports.fxSymbolsList = exports.fxSymbols = exports.fxSSE = exports.futuresSymbolsList = exports.futuresSymbols = exports.fundamentals = exports.fundOwnership = exports.forumWallStreetHorizon = exports.fortyF = exports.forex5SecondSSE = exports.forex1SecondSSE = exports.forex1MinuteSSE = exports.fiveYear = exports.fiveDayMLReturnRankingBrain = exports.fiscalQuarterEndWallStreetHorizon = exports.financials = exports.filingDueDatesWallStreetHorizon = exports.files = exports.figi = exports.fedfunds = exports.fdaAdvisoryCommitteeMeetingsWallStreetHorizon = exports.exchanges = exports.estimates = exports.esgUSPTOPatentGrantsExtractAlpha = exports.esgUSPTOPatentApplicationsExtractAlpha = exports.esgUSASpendingExtractAlpha = exports.esgSenateLobbyingExtractAlpha = exports.esgOSHAInspectionsExtractAlpha = exports.esgFECIndividualCampaingContributionsExtractAlpha = exports.esgEPAMilestonesExtractAlpha = exports.esgEPAEnforcementsExtractAlpha = exports.esgDOLVisaApplicationsExtractAlpha = exports.esgCPSCRecallsExtractAlpha = exports.esgCFPBComplaintsExtractAlpha = exports.earningsToday = exports.earnings = exports.downloadStockReportvaluEngine = exports.downloadReportNewConstructs = exports.download = exports.dividendsBasic = exports.dividends = exports.distribution = exports.directorAndOfficerChangesAuditAnalytics = exports.diesel = exports.delete_ = exports.delayedQuote = void 0;
exports.technicals = exports.tags = exports.tacticalModel1ExtractAlpha = exports.systemStats = exports.systemEventSSE = exports.symbolsList = exports.symbols = exports.summitMeetingsWallStreetHorizon = exports.summary = exports.stocksUSSSE = exports.stocksUSNoUTPSSE = exports.stocksUSNoUTP5SecondSSE = exports.stocksUSNoUTP1SecondSSE = exports.stocksUSNoUTP1MinuteSSE = exports.stocksUS5SecondSSE = exports.stocksUS1SecondSSE = exports.stocksUS1MinuteSSE = exports.stockSplits = exports.stockReportValuEngine = exports.status = exports.ssrStatusSSE = exports.spread = exports.splits = exports.spinoff = exports.socialSentimentStockTwits = exports.sixMonth = exports.similarityIndexFraudFactors = exports.shortInterest = exports.shareholderMeetingsWallStreetHorizon = exports.sevenDaySentimentBrain = exports.sentimentSSE = exports.sentiment = exports.seminarsWallStreetHorizon = exports.securitySwap = exports.securityReclassification = exports.securityEventSSE = exports.sectors = exports.sectorPerformance = exports.secondaryOfferingsWallStreetHorizon = exports.search = exports.schema = exports.sameStoreSalesWallStreetHorizon = exports.rules = exports.rule = exports.rightsIssue = exports.rightToPurchase = exports.ricLookup = exports.returnOfCapital = exports.retailMoney = exports.resume = exports.researchAndDevelopmentDaysWallStreetHorizon = exports.reportNewConstructs = exports.records = exports.recessionProb = exports.recent = exports.quote = exports.queryMetadata = exports.propane = exports.productEventsWallStreetHorizon = exports.priceTarget = exports.priceDynamicsPrecisionAlpha = exports.price = exports.previous = exports.points = exports.peers = exports.payroll = exports.payAsYouGo = exports.pause = exports.overrideUrl = exports.output = exports.otcSymbolsList = exports.otcSymbols = exports.optionsSymbolsList = exports.optionsSymbols = exports.options = exports.optionExpirations = exports.opHaltStatusSSE = exports.oneYear = exports.oneMonth = exports.ohlc = exports.officialPriceSSE = exports.nonTimelyFilingsFraudFactors = exports.newsSSE = exports.news = exports.natgas = exports.mutualFundSymbolsList = exports.mutualFundSymbols = exports.metadata = exports.messageBudget = exports.mergersAndAcquisitionsWallStreetHorizon = exports.marketYesterday = exports.marketVolume = exports.marketShortInterest = exports.marketPrevious = exports.marketOhlc = exports.marketNews = exports.lookup = exports.logo = exports.list = exports.legalActionsWallStreetHorizon = void 0;
exports.yesterday = exports.wti = exports.workshopsWallStreetHorizon = exports.witchingHoursWallStreetHorizon = exports.volumeByVenue = exports.vehicles = exports.usage = exports.us5 = exports.us30 = exports.us15 = exports.upcomingSplits = exports.upcomingIPOs = exports.upcomingEvents = exports.upcomingEarnings = exports.upcomingDividends = exports.unemployment = exports.twoYear = exports.twoDayMLReturnRankingBrain = exports.twentyYear = exports.twentyOneDayMLReturnRankingBrain = exports.twentyF = exports.tradingStatusSSE = exports.tradesSSE = exports.tradeShowsWallStreetHorizon = exports.tradeBreaksSSE = exports.topsSSE = exports.timeSeriesInventory = exports.timeSeries = exports.threshold = exports.threeMonth = exports.threeDayMLReturnRankingBrain = exports.thirtyYear = exports.thirtyDaySentimentBrain = exports.tenYear = exports.tenQ = exports.tenK = exports.tenDayMLReturnRankingBrain = void 0;
!function () {
  const t = {
    IEX_TOKEN: ""
  };

  try {
    if (process) return process.env = Object.assign({}, process.env), void Object.assign(process.env, t);
  } catch (t) {}

  globalThis.process = {
    env: t
  };
}();
var t = "0.3.0",
    e = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};

function o(t) {
  var e = {
    exports: {}
  };
  return t(e, e.exports), e.exports;
}

var r = function (t) {
  return t && t.Math == Math && t;
},
    n = r("object" == typeof globalThis && globalThis) || r("object" == typeof window && window) || r("object" == typeof self && self) || r("object" == typeof e && e) || function () {
  return this;
}() || Function("return this")(),
    i = function (t) {
  try {
    return !!t();
  } catch (t) {
    return !0;
  }
},
    s = !i(function () {
  return 7 != Object.defineProperty({}, 1, {
    get: function () {
      return 7;
    }
  })[1];
}),
    a = {}.propertyIsEnumerable,
    f = Object.getOwnPropertyDescriptor,
    u = {
  f: f && !a.call({
    1: 2
  }, 1) ? function (t) {
    var e = f(this, t);
    return !!e && e.enumerable;
  } : a
},
    c = function (t, e) {
  return {
    enumerable: !(1 & t),
    configurable: !(2 & t),
    writable: !(4 & t),
    value: e
  };
},
    l = {}.toString,
    p = function (t) {
  return l.call(t).slice(8, -1);
},
    m = "".split,
    v = i(function () {
  return !Object("z").propertyIsEnumerable(0);
}) ? function (t) {
  return "String" == p(t) ? m.call(t, "") : Object(t);
} : Object,
    k = function (t) {
  if (null == t) throw TypeError("Can't call method on " + t);
  return t;
},
    h = function (t) {
  return v(k(t));
},
    y = function (t) {
  return "object" == typeof t ? null !== t : "function" == typeof t;
},
    d = function (t, e) {
  if (!y(t)) return t;
  var o, r;
  if (e && "function" == typeof (o = t.toString) && !y(r = o.call(t))) return r;
  if ("function" == typeof (o = t.valueOf) && !y(r = o.call(t))) return r;
  if (!e && "function" == typeof (o = t.toString) && !y(r = o.call(t))) return r;
  throw TypeError("Can't convert object to primitive value");
},
    _ = function (t) {
  return Object(k(t));
},
    g = {}.hasOwnProperty,
    S = function (t, e) {
  return g.call(_(t), e);
},
    b = n.document,
    E = y(b) && y(b.createElement),
    R = function (t) {
  return E ? b.createElement(t) : {};
},
    $ = !s && !i(function () {
  return 7 != Object.defineProperty(R("div"), "a", {
    get: function () {
      return 7;
    }
  }).a;
}),
    A = Object.getOwnPropertyDescriptor,
    w = {
  f: s ? A : function (t, e) {
    if (t = h(t), e = d(e, !0), $) try {
      return A(t, e);
    } catch (t) {}
    if (S(t, e)) return c(!u.f.call(t, e), t[e]);
  }
},
    I = function (t) {
  if (!y(t)) throw TypeError(String(t) + " is not an object");
  return t;
},
    T = Object.defineProperty,
    x = {
  f: s ? T : function (t, e, o) {
    if (I(t), e = d(e, !0), I(o), $) try {
      return T(t, e, o);
    } catch (t) {}
    if ("get" in o || "set" in o) throw TypeError("Accessors not supported");
    return "value" in o && (t[e] = o.value), t;
  }
},
    O = s ? function (t, e, o) {
  return x.f(t, e, c(1, o));
} : function (t, e, o) {
  return t[e] = o, t;
},
    L = function (t, e) {
  try {
    O(n, t, e);
  } catch (o) {
    n[t] = e;
  }

  return e;
},
    M = n["__core-js_shared__"] || L("__core-js_shared__", {}),
    P = Function.toString;

"function" != typeof M.inspectSource && (M.inspectSource = function (t) {
  return P.call(t);
});

var U,
    N,
    C,
    D = M.inspectSource,
    j = n.WeakMap,
    F = "function" == typeof j && /native code/.test(D(j)),
    G = o(function (t) {
  (t.exports = function (t, e) {
    return M[t] || (M[t] = void 0 !== e ? e : {});
  })("versions", []).push({
    version: "3.11.1",
    mode: "global",
    copyright: "© 2021 Denis Pushkarev (zloirock.ru)"
  });
}),
    q = 0,
    H = Math.random(),
    B = function (t) {
  return "Symbol(" + String(void 0 === t ? "" : t) + ")_" + (++q + H).toString(36);
},
    W = G("keys"),
    Y = function (t) {
  return W[t] || (W[t] = B(t));
},
    X = {},
    Z = n.WeakMap;

if (F) {
  var K = M.state || (M.state = new Z()),
      V = K.get,
      z = K.has,
      Q = K.set;
  U = function (t, e) {
    if (z.call(K, t)) throw new TypeError("Object already initialized");
    return e.facade = t, Q.call(K, t, e), e;
  }, N = function (t) {
    return V.call(K, t) || {};
  }, C = function (t) {
    return z.call(K, t);
  };
} else {
  var J = Y("state");
  X[J] = !0, U = function (t, e) {
    if (S(t, J)) throw new TypeError("Object already initialized");
    return e.facade = t, O(t, J, e), e;
  }, N = function (t) {
    return S(t, J) ? t[J] : {};
  }, C = function (t) {
    return S(t, J);
  };
}

var tt = {
  set: U,
  get: N,
  has: C,
  enforce: function (t) {
    return C(t) ? N(t) : U(t, {});
  },
  getterFor: function (t) {
    return function (e) {
      var o;
      if (!y(e) || (o = N(e)).type !== t) throw TypeError("Incompatible receiver, " + t + " required");
      return o;
    };
  }
},
    et = o(function (t) {
  var e = tt.get,
      o = tt.enforce,
      r = String(String).split("String");
  (t.exports = function (t, e, i, s) {
    var a,
        f = !!s && !!s.unsafe,
        u = !!s && !!s.enumerable,
        c = !!s && !!s.noTargetGet;
    "function" == typeof i && ("string" != typeof e || S(i, "name") || O(i, "name", e), (a = o(i)).source || (a.source = r.join("string" == typeof e ? e : ""))), t !== n ? (f ? !c && t[e] && (u = !0) : delete t[e], u ? t[e] = i : O(t, e, i)) : u ? t[e] = i : L(e, i);
  })(Function.prototype, "toString", function () {
    return "function" == typeof this && e(this).source || D(this);
  });
}),
    ot = n,
    rt = function (t) {
  return "function" == typeof t ? t : void 0;
},
    nt = function (t, e) {
  return arguments.length < 2 ? rt(ot[t]) || rt(n[t]) : ot[t] && ot[t][e] || n[t] && n[t][e];
},
    it = Math.ceil,
    st = Math.floor,
    at = function (t) {
  return isNaN(t = +t) ? 0 : (t > 0 ? st : it)(t);
},
    ft = Math.min,
    ut = function (t) {
  return t > 0 ? ft(at(t), 9007199254740991) : 0;
},
    ct = Math.max,
    lt = Math.min,
    pt = function (t) {
  return function (e, o, r) {
    var n,
        i = h(e),
        s = ut(i.length),
        a = function (t, e) {
      var o = at(t);
      return o < 0 ? ct(o + e, 0) : lt(o, e);
    }(r, s);

    if (t && o != o) {
      for (; s > a;) if ((n = i[a++]) != n) return !0;
    } else for (; s > a; a++) if ((t || a in i) && i[a] === o) return t || a || 0;

    return !t && -1;
  };
},
    mt = {
  includes: pt(!0),
  indexOf: pt(!1)
}.indexOf,
    vt = function (t, e) {
  var o,
      r = h(t),
      n = 0,
      i = [];

  for (o in r) !S(X, o) && S(r, o) && i.push(o);

  for (; e.length > n;) S(r, o = e[n++]) && (~mt(i, o) || i.push(o));

  return i;
},
    kt = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"],
    ht = kt.concat("length", "prototype"),
    yt = {
  f: Object.getOwnPropertyNames || function (t) {
    return vt(t, ht);
  }
},
    dt = {
  f: Object.getOwnPropertySymbols
},
    _t = nt("Reflect", "ownKeys") || function (t) {
  var e = yt.f(I(t)),
      o = dt.f;
  return o ? e.concat(o(t)) : e;
},
    gt = function (t, e) {
  for (var o = _t(e), r = x.f, n = w.f, i = 0; i < o.length; i++) {
    var s = o[i];
    S(t, s) || r(t, s, n(e, s));
  }
},
    St = /#|\.prototype\./,
    bt = function (t, e) {
  var o = Rt[Et(t)];
  return o == At || o != $t && ("function" == typeof e ? i(e) : !!e);
},
    Et = bt.normalize = function (t) {
  return String(t).replace(St, ".").toLowerCase();
},
    Rt = bt.data = {},
    $t = bt.NATIVE = "N",
    At = bt.POLYFILL = "P",
    wt = bt,
    It = w.f,
    Tt = function (t, e) {
  var o,
      r,
      i,
      s,
      a,
      f = t.target,
      u = t.global,
      c = t.stat;
  if (o = u ? n : c ? n[f] || L(f, {}) : (n[f] || {}).prototype) for (r in e) {
    if (s = e[r], i = t.noTargetGet ? (a = It(o, r)) && a.value : o[r], !wt(u ? r : f + (c ? "." : "#") + r, t.forced) && void 0 !== i) {
      if (typeof s == typeof i) continue;
      gt(s, i);
    }

    (t.sham || i && i.sham) && O(s, "sham", !0), et(o, r, s, t);
  }
},
    xt = function () {
  var t = I(this),
      e = "";
  return t.global && (e += "g"), t.ignoreCase && (e += "i"), t.multiline && (e += "m"), t.dotAll && (e += "s"), t.unicode && (e += "u"), t.sticky && (e += "y"), e;
};

function Ot(t, e) {
  return RegExp(t, e);
}

var Lt,
    Mt,
    Pt = {
  UNSUPPORTED_Y: i(function () {
    var t = Ot("a", "y");
    return t.lastIndex = 2, null != t.exec("abcd");
  }),
  BROKEN_CARET: i(function () {
    var t = Ot("^r", "gy");
    return t.lastIndex = 2, null != t.exec("str");
  })
},
    Ut = RegExp.prototype.exec,
    Nt = G("native-string-replace", String.prototype.replace),
    Ct = Ut,
    Dt = (Lt = /a/, Mt = /b*/g, Ut.call(Lt, "a"), Ut.call(Mt, "a"), 0 !== Lt.lastIndex || 0 !== Mt.lastIndex),
    jt = Pt.UNSUPPORTED_Y || Pt.BROKEN_CARET,
    Ft = void 0 !== /()??/.exec("")[1];
(Dt || Ft || jt) && (Ct = function (t) {
  var e,
      o,
      r,
      n,
      i = this,
      s = jt && i.sticky,
      a = xt.call(i),
      f = i.source,
      u = 0,
      c = t;
  return s && (-1 === (a = a.replace("y", "")).indexOf("g") && (a += "g"), c = String(t).slice(i.lastIndex), i.lastIndex > 0 && (!i.multiline || i.multiline && "\n" !== t[i.lastIndex - 1]) && (f = "(?: " + f + ")", c = " " + c, u++), o = new RegExp("^(?:" + f + ")", a)), Ft && (o = new RegExp("^" + f + "$(?!\\s)", a)), Dt && (e = i.lastIndex), r = Ut.call(s ? o : i, c), s ? r ? (r.input = r.input.slice(u), r[0] = r[0].slice(u), r.index = i.lastIndex, i.lastIndex += r[0].length) : i.lastIndex = 0 : Dt && r && (i.lastIndex = i.global ? r.index + r[0].length : e), Ft && r && r.length > 1 && Nt.call(r[0], o, function () {
    for (n = 1; n < arguments.length - 2; n++) void 0 === arguments[n] && (r[n] = void 0);
  }), r;
});
var Gt = Ct;
Tt({
  target: "RegExp",
  proto: !0,
  forced: /./.exec !== Gt
}, {
  exec: Gt
});
var qt,
    Ht,
    Bt = "process" == p(n.process),
    Wt = nt("navigator", "userAgent") || "",
    Yt = n.process,
    Xt = Yt && Yt.versions,
    Zt = Xt && Xt.v8;
Zt ? Ht = (qt = Zt.split("."))[0] + qt[1] : Wt && (!(qt = Wt.match(/Edge\/(\d+)/)) || qt[1] >= 74) && (qt = Wt.match(/Chrome\/(\d+)/)) && (Ht = qt[1]);

var Kt = Ht && +Ht,
    Vt = !!Object.getOwnPropertySymbols && !i(function () {
  return !Symbol.sham && (Bt ? 38 === Kt : Kt > 37 && Kt < 41);
}),
    zt = Vt && !Symbol.sham && "symbol" == typeof Symbol.iterator,
    Qt = G("wks"),
    Jt = n.Symbol,
    te = zt ? Jt : Jt && Jt.withoutSetter || B,
    ee = function (t) {
  return S(Qt, t) && (Vt || "string" == typeof Qt[t]) || (Vt && S(Jt, t) ? Qt[t] = Jt[t] : Qt[t] = te("Symbol." + t)), Qt[t];
},
    oe = ee("species"),
    re = !i(function () {
  var t = /./;
  return t.exec = function () {
    var t = [];
    return t.groups = {
      a: "7"
    }, t;
  }, "7" !== "".replace(t, "$<a>");
}),
    ne = "$0" === "a".replace(/./, "$0"),
    ie = ee("replace"),
    se = !!/./[ie] && "" === /./[ie]("a", "$0"),
    ae = !i(function () {
  var t = /(?:)/,
      e = t.exec;

  t.exec = function () {
    return e.apply(this, arguments);
  };

  var o = "ab".split(t);
  return 2 !== o.length || "a" !== o[0] || "b" !== o[1];
}),
    fe = function (t) {
  return function (e, o) {
    var r,
        n,
        i = String(k(e)),
        s = at(o),
        a = i.length;
    return s < 0 || s >= a ? t ? "" : void 0 : (r = i.charCodeAt(s)) < 55296 || r > 56319 || s + 1 === a || (n = i.charCodeAt(s + 1)) < 56320 || n > 57343 ? t ? i.charAt(s) : r : t ? i.slice(s, s + 2) : n - 56320 + (r - 55296 << 10) + 65536;
  };
},
    ue = {
  codeAt: fe(!1),
  charAt: fe(!0)
},
    ce = ue.charAt,
    le = function (t, e, o) {
  return e + (o ? ce(t, e).length : 1);
},
    pe = Math.floor,
    me = "".replace,
    ve = /\$([$&'`]|\d{1,2}|<[^>]*>)/g,
    ke = /\$([$&'`]|\d{1,2})/g,
    he = function (t, e, o, r, n, i) {
  var s = o + t.length,
      a = r.length,
      f = ke;
  return void 0 !== n && (n = _(n), f = ve), me.call(i, f, function (i, f) {
    var u;

    switch (f.charAt(0)) {
      case "$":
        return "$";

      case "&":
        return t;

      case "`":
        return e.slice(0, o);

      case "'":
        return e.slice(s);

      case "<":
        u = n[f.slice(1, -1)];
        break;

      default:
        var c = +f;
        if (0 === c) return i;

        if (c > a) {
          var l = pe(c / 10);
          return 0 === l ? i : l <= a ? void 0 === r[l - 1] ? f.charAt(1) : r[l - 1] + f.charAt(1) : i;
        }

        u = r[c - 1];
    }

    return void 0 === u ? "" : u;
  });
},
    ye = function (t, e) {
  var o = t.exec;

  if ("function" == typeof o) {
    var r = o.call(t, e);
    if ("object" != typeof r) throw TypeError("RegExp exec method returned something other than an Object or null");
    return r;
  }

  if ("RegExp" !== p(t)) throw TypeError("RegExp#exec called on incompatible receiver");
  return Gt.call(t, e);
},
    de = Math.max,
    _e = Math.min;

function ge(t) {
  return new Error(t);
}

!function (t, e, o, r) {
  var n = ee(t),
      s = !i(function () {
    var e = {};
    return e[n] = function () {
      return 7;
    }, 7 != ""[t](e);
  }),
      a = s && !i(function () {
    var e = !1,
        o = /a/;
    return "split" === t && ((o = {}).constructor = {}, o.constructor[oe] = function () {
      return o;
    }, o.flags = "", o[n] = /./[n]), o.exec = function () {
      return e = !0, null;
    }, o[n](""), !e;
  });

  if (!s || !a || "replace" === t && (!re || !ne || se) || "split" === t && !ae) {
    var f = /./[n],
        u = o(n, ""[t], function (t, e, o, r, n) {
      return e.exec === RegExp.prototype.exec ? s && !n ? {
        done: !0,
        value: f.call(e, o, r)
      } : {
        done: !0,
        value: t.call(o, e, r)
      } : {
        done: !1
      };
    }, {
      REPLACE_KEEPS_$0: ne,
      REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE: se
    }),
        c = u[0],
        l = u[1];
    et(String.prototype, t, c), et(RegExp.prototype, n, 2 == e ? function (t, e) {
      return l.call(t, this, e);
    } : function (t) {
      return l.call(t, this);
    });
  }

  r && O(RegExp.prototype[n], "sham", !0);
}("replace", 2, function (t, e, o, r) {
  var n = r.REGEXP_REPLACE_SUBSTITUTES_UNDEFINED_CAPTURE,
      i = r.REPLACE_KEEPS_$0,
      s = n ? "$" : "$0";
  return [function (o, r) {
    var n = k(this),
        i = null == o ? void 0 : o[t];
    return void 0 !== i ? i.call(o, n, r) : e.call(String(n), o, r);
  }, function (t, r) {
    if (!n && i || "string" == typeof r && -1 === r.indexOf(s)) {
      var a = o(e, t, this, r);
      if (a.done) return a.value;
    }

    var f = I(t),
        u = String(this),
        c = "function" == typeof r;
    c || (r = String(r));
    var l = f.global;

    if (l) {
      var p = f.unicode;
      f.lastIndex = 0;
    }

    for (var m = [];;) {
      var v = ye(f, u);
      if (null === v) break;
      if (m.push(v), !l) break;
      "" === String(v[0]) && (f.lastIndex = le(u, ut(f.lastIndex), p));
    }

    for (var k, h = "", y = 0, d = 0; d < m.length; d++) {
      v = m[d];

      for (var _ = String(v[0]), g = de(_e(at(v.index), u.length), 0), S = [], b = 1; b < v.length; b++) S.push(void 0 === (k = v[b]) ? k : String(k));

      var E = v.groups;

      if (c) {
        var R = [_].concat(S, g, u);
        void 0 !== E && R.push(E);
        var $ = String(r.apply(void 0, R));
      } else $ = he(_, u, g, S, E, r);

      g >= y && (h += u.slice(y, g) + $, y = g + _.length);
    }

    return h + u.slice(y);
  }];
}), ge.prototype = Object.create(Error.prototype);

const Se = /^((q|Q)[1-4]|(h|H)[1-2])?(1|2)(0|9)[0-9][0-9]/,
      be = /^[0-9]+(y|q|m|w|d)/,
      Ee = ["max", "5y", "2y", "1y", "ytd", "6m", "3m", "1m", "1mm", "5d", "5dm", "1d", "dynamic"],
      Re = ["5y", "2y", "1y", "ytd", "6m", "3m", "1m", "next"],
      $e = ["mostactive", "gainers", "losers", "iexvolume", "iexpercent"],
      Ae = ["sector", "tag", "list"],
      we = ["today", "yesterday", "ytd", "last-week", "last-month", "last-quarter", "d", "w", "m", "q", "y", "tomorrow", "this-week", "this-month", "this-quarter", "next-week", "next-month", "next-quarter"],
      Ie = ["companyName", "marketcap", "week52high", "week52low", "week52change", "sharesOutstanding", "float", "avg10Volume", "avg30Volume", "day200MovingAvg", "day50MovingAvg", "employees", "ttmEPS", "ttmDividendRate", "dividendYield", "nextDividendDate", "exDividendDate", "nextEarningsDate", "peRatio", "beta", "maxChangePercent", "year5ChangePercent", "year2ChangePercent", "year1ChangePercent", "ytdChangePercent", "month6ChangePercent", "month3ChangePercent", "month1ChangePercent", "day30ChangePercent", "day5ChangePercent"],
      Te = ["messages", "rules", "rule-records", "alerts", "alert-records"],
      xe = ["book", "chart", "company", "dividends", "earnings", "financials", "stats", "news", "peers", "splits", "intraday-prices", "effective-spread", "delayed-quote", "largest-trades", "previous", "price", "quote", "relevant", "volume-by-venue"],
      Oe = ["consensusEndDate", "consensusStartDate", "DailyListTimestamp", "date", "datetime", "declaredDate", "EPSReportDate", "endDate", "exDate", "expectedDate", "expirationDate", "fiscalEndDate", "latestTime", "lastTradeDate", "lastUpdated", "paymentDate", "processedTime", "recordDate", "RecordUpdateTime", "reportDate", "settlementDate", "startDate"],
      Le = ["closeTime", "close.time", "delayedPriceTime", "extendedPriceTime", "highTime", "iexCloseTime", "iexLastUpdated", "iexOpenTime", "lastTradeTime", "lastUpdated", "latestTime", "latestUpdate", "lowTime", "oddLotDelayedPriceTime", "openTime", "open.time", "processedTime", "report_date", "reportDate", "time", "timestamp", "updated"],
      Me = ["abs", "acos", "ad", "add", "adosc", "adx", "adxr", "ao", "apo", "aroon", "aroonosc", "asin", "atan", "atr", "avgprice", "bbands", "bop", "cci", "ceil", "cmo", "cos", "cosh", "crossany", "crossover", "cvi", "decay", "dema", "di", "div", "dm", "dpo", "dx", "edecay", "ema", "emv", "exp", "fisher", "floor", "fosc", "hma", "kama", "kvo", "lag", "linreg", "linregintercept", "linregslope", "ln", "log10", "macd", "marketfi", "mass", "max", "md", "medprice", "mfi", "min", "mom", "msw", "mul", "natr", "nvi", "obv", "ppo", "psar", "pvi", "qstick", "roc", "rocr", "round", "rsi", "sin", "sinh", "sma", "sqrt", "stddev", "stderr", "stoch", "stochrsi", "sub", "sum", "tan", "tanh", "tema", "todeg", "torad", "tr", "trima", "trix", "trunc", "tsf", "typprice", "ultosc", "var", "vhf", "vidya", "volatility", "vosc", "vwma", "wad", "wcprice", "wilders", "willr", "wma", "zlema"],
      Pe = {
  abs: ["abs"],
  acos: ["acos"],
  ad: ["ad"],
  add: ["add"],
  adosc: ["adosc"],
  adx: ["dx"],
  adxr: ["dx"],
  ao: ["ao"],
  apo: ["apo"],
  aroon: ["aroon_down", "aroon_up"],
  aroonosc: ["aroonosc"],
  asin: ["asin"],
  atan: ["atan"],
  atr: ["atr"],
  avgprice: ["avgprice"],
  bbands: ["bbands_lower", "bbands_middle", "bbands_upper"],
  bop: ["bop"],
  cci: ["cci"],
  ceil: ["ceil"],
  cmo: ["cmo"],
  cos: ["cos"],
  cosh: ["cosh"],
  crossany: ["crossany"],
  crossover: ["crossover"],
  cvi: ["cvi"],
  decay: ["decay"],
  dema: ["dema"],
  di: ["plus_di", "minus_di"],
  div: ["div"],
  dm: ["plus_dm", "minus_dm"],
  dpo: ["dop"],
  dx: ["dx"],
  edecay: ["edecay"],
  ema: ["ema"],
  emv: ["emv"],
  exp: ["exp"],
  fisher: ["fisher", "fisher_signal"],
  floor: ["floor"],
  fosc: ["fosc"],
  hma: ["hma"],
  kama: ["kama"],
  kvo: ["kvo"],
  lag: ["lag"],
  linreg: ["linreg"],
  linregintercept: ["linregintercept"],
  linregslope: ["linregslope"],
  ln: ["ln"],
  log10: ["log10"],
  macd: ["macd", "macd_signal", "macd_histogram"],
  marketfi: ["marketfi"],
  mass: ["mass"],
  max: ["max"],
  md: ["md"],
  medprice: ["medprice"],
  mfi: ["mfi"],
  min: ["min"],
  mom: ["mom"],
  msw: ["msw_sine", "msw_lead"],
  mul: ["mul"],
  natr: ["matr"],
  nvi: ["nvi"],
  obv: ["obv"],
  ppo: ["ppo"],
  psar: ["psar"],
  pvi: ["pvi"],
  qstick: ["qstick"],
  roc: ["roc"],
  rocr: ["rocr"],
  round: ["round"],
  rsi: ["rsi"],
  sin: ["sin"],
  sinh: ["sinh"],
  sma: ["sma"],
  sqrt: ["sqrt"],
  stddev: ["stddev"],
  stderr: ["stderr"],
  stoch: ["stock_k", "stock_d"],
  stochrsi: ["stochrsi"],
  sub: ["sub"],
  sum: ["sum"],
  tan: ["tan"],
  tanh: ["tanh"],
  tema: ["tema"],
  todeg: ["degrees"],
  torad: ["radians"],
  tr: ["tr"],
  trima: ["trima"],
  trix: ["trix"],
  trunc: ["trunc"],
  tsf: ["tsf"],
  typprice: ["typprice"],
  ultosc: ["ultosc"],
  var: ["var"],
  vhf: ["vhf"],
  vidya: ["vidya"],
  volatility: ["volatility"],
  vosc: ["vosc"],
  vwma: ["vwma"],
  wad: ["wad"],
  wcprice: ["wcprice"],
  wilders: ["wilders"],
  willr: ["willr"],
  wma: ["wma"],
  zlema: ["zlema"]
},
      Ue = t => "string" == typeof t ? [t] : t,
      Ne = t => Ue(t).join(","),
      Ce = t => {
  if ("string" == typeof t) return t;
  if (t instanceof Date) return t.toISOString().slice(0, 10).replace(/-/g, "");
  throw ge(`Not a date: ${typeof t} ${t}`);
},
      De = t => {
  if (we.indexOf(t) < 0 && !be.test(t) && !Se.test(t)) throw ge(`Must be a valid date range: got ${t}`);
  return t;
},
      je = t => {
  if ("string" != typeof t) throw ge("Cannot use type " + typeof t);
},
      Fe = (t, e) => {
  if ("quarter" !== t && "annual" !== t) throw ge("Period must be in {'quarter', 'annual'}");

  if ("quarter" === t) {
    if (e < 1 || e > 12) throw ge("Last must be in [1, 12] for period 'quarter'");
  } else if (e < 1 || e > 4) throw ge("Last must be in [1, 4] for period 'annual'");
},
      Ge = (t, e = !0) => {
  if (!(t.startsWith("sk") || e && t.startsWith("Tsk"))) throw ge("Requires secret token!");
},
      qe = t => Array.isArray(t) ? t.map(t => encodeURIComponent(t)).join(",") : encodeURIComponent(t),
      He = (t, e = !0, o = !0) => {
  if (e) {
    const {
      key: e
    } = t || {};
    if (null != e) throw ge("Cannot pass `key` argument to timeseries, already used");
  }

  if (o) {
    const {
      subkey: e
    } = t || {};
    if (null != e) throw ge("Cannot pass `subkey` argument to timeseries, already used");
  }
};

exports._timeseriesWrapper = He;
exports._quoteSymbols = qe;
exports._requireSecret = Ge;
exports._checkPeriodLast = Fe;
exports._raiseIfNotStr = je;
exports._dateRange = De;
exports._strOrDate = Ce;
exports._strCommaSeparatedString = Ne;
exports._strToList = Ue;
exports._INDICATOR_RETURNS = Pe;
exports._INDICATORS = Me;
exports._STANDARD_TIME_FIELDS = Le;
exports._STANDARD_DATE_FIELDS = Oe;
exports._BATCH_TYPES = xe;
exports._USAGE_TYPES = Te;
exports._KEY_STATS = Ie;
exports._DATE_RANGES = we;
exports._COLLECTION_TAGS = Ae;
exports._LIST_OPTIONS = $e;
exports._TIMEFRAME_DIVSPLIT = Re;
exports._TIMEFRAME_CHART = Ee;

var Be,
    We = {
  CSSRuleList: 0,
  CSSStyleDeclaration: 0,
  CSSValueList: 0,
  ClientRectList: 0,
  DOMRectList: 0,
  DOMStringList: 0,
  DOMTokenList: 1,
  DataTransferItemList: 0,
  FileList: 0,
  HTMLAllCollection: 0,
  HTMLCollection: 0,
  HTMLFormElement: 0,
  HTMLSelectElement: 0,
  MediaList: 0,
  MimeTypeArray: 0,
  NamedNodeMap: 0,
  NodeList: 1,
  PaintRequestList: 0,
  Plugin: 0,
  PluginArray: 0,
  SVGLengthList: 0,
  SVGNumberList: 0,
  SVGPathSegList: 0,
  SVGPointList: 0,
  SVGStringList: 0,
  SVGTransformList: 0,
  SourceBufferList: 0,
  StyleSheetList: 0,
  TextTrackCueList: 0,
  TextTrackList: 0,
  TouchList: 0
},
    Ye = Object.keys || function (t) {
  return vt(t, kt);
},
    Xe = s ? Object.defineProperties : function (t, e) {
  I(t);

  for (var o, r = Ye(e), n = r.length, i = 0; n > i;) x.f(t, o = r[i++], e[o]);

  return t;
},
    Ze = nt("document", "documentElement"),
    Ke = Y("IE_PROTO"),
    Ve = function () {},
    ze = function (t) {
  return "<script>" + t + "<\/script>";
},
    Qe = function () {
  try {
    Be = document.domain && new ActiveXObject("htmlfile");
  } catch (t) {}

  var t, e;
  Qe = Be ? function (t) {
    t.write(ze("")), t.close();
    var e = t.parentWindow.Object;
    return t = null, e;
  }(Be) : ((e = R("iframe")).style.display = "none", Ze.appendChild(e), e.src = String("javascript:"), (t = e.contentWindow.document).open(), t.write(ze("document.F=Object")), t.close(), t.F);

  for (var o = kt.length; o--;) delete Qe.prototype[kt[o]];

  return Qe();
};

X[Ke] = !0;

var Je = Object.create || function (t, e) {
  var o;
  return null !== t ? (Ve.prototype = I(t), o = new Ve(), Ve.prototype = null, o[Ke] = t) : o = Qe(), void 0 === e ? o : Xe(o, e);
},
    to = ee("unscopables"),
    eo = Array.prototype;

null == eo[to] && x.f(eo, to, {
  configurable: !0,
  value: Je(null)
});

var oo,
    ro,
    no,
    io = function (t) {
  eo[to][t] = !0;
},
    so = {},
    ao = !i(function () {
  function t() {}

  return t.prototype.constructor = null, Object.getPrototypeOf(new t()) !== t.prototype;
}),
    fo = Y("IE_PROTO"),
    uo = Object.prototype,
    co = ao ? Object.getPrototypeOf : function (t) {
  return t = _(t), S(t, fo) ? t[fo] : "function" == typeof t.constructor && t instanceof t.constructor ? t.constructor.prototype : t instanceof Object ? uo : null;
},
    lo = ee("iterator"),
    po = !1;

[].keys && ("next" in (no = [].keys()) ? (ro = co(co(no))) !== Object.prototype && (oo = ro) : po = !0), (null == oo || i(function () {
  var t = {};
  return oo[lo].call(t) !== t;
})) && (oo = {}), S(oo, lo) || O(oo, lo, function () {
  return this;
});

var mo = {
  IteratorPrototype: oo,
  BUGGY_SAFARI_ITERATORS: po
},
    vo = x.f,
    ko = ee("toStringTag"),
    ho = function (t, e, o) {
  t && !S(t = o ? t : t.prototype, ko) && vo(t, ko, {
    configurable: !0,
    value: e
  });
},
    yo = mo.IteratorPrototype,
    _o = function () {
  return this;
},
    go = function (t, e, o) {
  var r = e + " Iterator";
  return t.prototype = Je(yo, {
    next: c(1, o)
  }), ho(t, r, !1), so[r] = _o, t;
},
    So = Object.setPrototypeOf || ("__proto__" in {} ? function () {
  var t,
      e = !1,
      o = {};

  try {
    (t = Object.getOwnPropertyDescriptor(Object.prototype, "__proto__").set).call(o, []), e = o instanceof Array;
  } catch (t) {}

  return function (o, r) {
    return I(o), function (t) {
      if (!y(t) && null !== t) throw TypeError("Can't set " + String(t) + " as a prototype");
    }(r), e ? t.call(o, r) : o.__proto__ = r, o;
  };
}() : void 0),
    bo = mo.IteratorPrototype,
    Eo = mo.BUGGY_SAFARI_ITERATORS,
    Ro = ee("iterator"),
    $o = function () {
  return this;
},
    Ao = function (t, e, o, r, n, i, s) {
  go(o, e, r);

  var a,
      f,
      u,
      c = function (t) {
    if (t === n && k) return k;
    if (!Eo && t in m) return m[t];

    switch (t) {
      case "keys":
      case "values":
      case "entries":
        return function () {
          return new o(this, t);
        };
    }

    return function () {
      return new o(this);
    };
  },
      l = e + " Iterator",
      p = !1,
      m = t.prototype,
      v = m[Ro] || m["@@iterator"] || n && m[n],
      k = !Eo && v || c(n),
      h = "Array" == e && m.entries || v;

  if (h && (a = co(h.call(new t())), bo !== Object.prototype && a.next && (co(a) !== bo && (So ? So(a, bo) : "function" != typeof a[Ro] && O(a, Ro, $o)), ho(a, l, !0))), "values" == n && v && "values" !== v.name && (p = !0, k = function () {
    return v.call(this);
  }), m[Ro] !== k && O(m, Ro, k), so[e] = k, n) if (f = {
    values: c("values"),
    keys: i ? k : c("keys"),
    entries: c("entries")
  }, s) for (u in f) (Eo || p || !(u in m)) && et(m, u, f[u]);else Tt({
    target: e,
    proto: !0,
    forced: Eo || p
  }, f);
  return f;
},
    wo = tt.set,
    Io = tt.getterFor("Array Iterator"),
    To = Ao(Array, "Array", function (t, e) {
  wo(this, {
    type: "Array Iterator",
    target: h(t),
    index: 0,
    kind: e
  });
}, function () {
  var t = Io(this),
      e = t.target,
      o = t.kind,
      r = t.index++;
  return !e || r >= e.length ? (t.target = void 0, {
    value: void 0,
    done: !0
  }) : "keys" == o ? {
    value: r,
    done: !1
  } : "values" == o ? {
    value: e[r],
    done: !1
  } : {
    value: [r, e[r]],
    done: !1
  };
}, "values");

so.Arguments = so.Array, io("keys"), io("values"), io("entries");
var xo = ee("iterator"),
    Oo = ee("toStringTag"),
    Lo = To.values;

for (var Mo in We) {
  var Po = n[Mo],
      Uo = Po && Po.prototype;

  if (Uo) {
    if (Uo[xo] !== Lo) try {
      O(Uo, xo, Lo);
    } catch (t) {
      Uo[xo] = Lo;
    }
    if (Uo[Oo] || O(Uo, Oo, Mo), We[Mo]) for (var No in To) if (Uo[No] !== To[No]) try {
      O(Uo, No, To[No]);
    } catch (t) {
      Uo[No] = To[No];
    }
  }
}

var Co = ue.charAt,
    Do = tt.set,
    jo = tt.getterFor("String Iterator");
Ao(String, "String", function (t) {
  Do(this, {
    type: "String Iterator",
    string: String(t),
    index: 0
  });
}, function () {
  var t,
      e = jo(this),
      o = e.string,
      r = e.index;
  return r >= o.length ? {
    value: void 0,
    done: !0
  } : (t = Co(o, r), e.index += t.length, {
    value: t,
    done: !1
  });
});

var Fo = ee("iterator"),
    Go = !i(function () {
  var t = new URL("b?a=1&b=2&c=3", "http://a"),
      e = t.searchParams,
      o = "";
  return t.pathname = "c%20d", e.forEach(function (t, r) {
    e.delete("b"), o += r + t;
  }), !e.sort || "http://a/c%20d?a=1&c=3" !== t.href || "3" !== e.get("c") || "a=1" !== String(new URLSearchParams("?a=1")) || !e[Fo] || "a" !== new URL("https://a@b").username || "b" !== new URLSearchParams(new URLSearchParams("a=b")).get("a") || "xn--e1aybc" !== new URL("http://тест").host || "#%D0%B1" !== new URL("http://a#б").hash || "a1c3" !== o || "x" !== new URL("http://x", void 0).host;
}),
    qo = function (t, e, o) {
  if (!(t instanceof e)) throw TypeError("Incorrect " + (o ? o + " " : "") + "invocation");
  return t;
},
    Ho = Object.assign,
    Bo = Object.defineProperty,
    Wo = !Ho || i(function () {
  if (s && 1 !== Ho({
    b: 1
  }, Ho(Bo({}, "a", {
    enumerable: !0,
    get: function () {
      Bo(this, "b", {
        value: 3,
        enumerable: !1
      });
    }
  }), {
    b: 2
  })).b) return !0;
  var t = {},
      e = {},
      o = Symbol(),
      r = "abcdefghijklmnopqrst";
  return t[o] = 7, r.split("").forEach(function (t) {
    e[t] = t;
  }), 7 != Ho({}, t)[o] || Ye(Ho({}, e)).join("") != r;
}) ? function (t, e) {
  for (var o = _(t), r = arguments.length, n = 1, i = dt.f, a = u.f; r > n;) for (var f, c = v(arguments[n++]), l = i ? Ye(c).concat(i(c)) : Ye(c), p = l.length, m = 0; p > m;) f = l[m++], s && !a.call(c, f) || (o[f] = c[f]);

  return o;
} : Ho,
    Yo = function (t, e, o) {
  if (function (t) {
    if ("function" != typeof t) throw TypeError(String(t) + " is not a function");
  }(t), void 0 === e) return t;

  switch (o) {
    case 0:
      return function () {
        return t.call(e);
      };

    case 1:
      return function (o) {
        return t.call(e, o);
      };

    case 2:
      return function (o, r) {
        return t.call(e, o, r);
      };

    case 3:
      return function (o, r, n) {
        return t.call(e, o, r, n);
      };
  }

  return function () {
    return t.apply(e, arguments);
  };
},
    Xo = function (t, e, o, r) {
  try {
    return r ? e(I(o)[0], o[1]) : e(o);
  } catch (e) {
    throw function (t) {
      var e = t.return;
      if (void 0 !== e) I(e.call(t)).value;
    }(t), e;
  }
},
    Zo = ee("iterator"),
    Ko = Array.prototype,
    Vo = function (t) {
  return void 0 !== t && (so.Array === t || Ko[Zo] === t);
},
    zo = function (t, e, o) {
  var r = d(e);
  r in t ? x.f(t, r, c(0, o)) : t[r] = o;
},
    Qo = {};

Qo[ee("toStringTag")] = "z";

var Jo = "[object z]" === String(Qo),
    tr = ee("toStringTag"),
    er = "Arguments" == p(function () {
  return arguments;
}()),
    or = Jo ? p : function (t) {
  var e, o, r;
  return void 0 === t ? "Undefined" : null === t ? "Null" : "string" == typeof (o = function (t, e) {
    try {
      return t[e];
    } catch (t) {}
  }(e = Object(t), tr)) ? o : er ? p(e) : "Object" == (r = p(e)) && "function" == typeof e.callee ? "Arguments" : r;
},
    rr = ee("iterator"),
    nr = function (t) {
  if (null != t) return t[rr] || t["@@iterator"] || so[or(t)];
},
    ir = function (t) {
  var e,
      o,
      r,
      n,
      i,
      s,
      a = _(t),
      f = "function" == typeof this ? this : Array,
      u = arguments.length,
      c = u > 1 ? arguments[1] : void 0,
      l = void 0 !== c,
      p = nr(a),
      m = 0;

  if (l && (c = Yo(c, u > 2 ? arguments[2] : void 0, 2)), null == p || f == Array && Vo(p)) for (o = new f(e = ut(a.length)); e > m; m++) s = l ? c(a[m], m) : a[m], zo(o, m, s);else for (i = (n = p.call(a)).next, o = new f(); !(r = i.call(n)).done; m++) s = l ? Xo(n, c, [r.value, m], !0) : r.value, zo(o, m, s);
  return o.length = m, o;
},
    sr = /[^\0-\u007E]/,
    ar = /[.\u3002\uFF0E\uFF61]/g,
    fr = "Overflow: input needs wider integers to process",
    ur = Math.floor,
    cr = String.fromCharCode,
    lr = function (t) {
  return t + 22 + 75 * (t < 26);
},
    pr = function (t, e, o) {
  var r = 0;

  for (t = o ? ur(t / 700) : t >> 1, t += ur(t / e); t > 455; r += 36) t = ur(t / 35);

  return ur(r + 36 * t / (t + 38));
},
    mr = function (t) {
  var e,
      o,
      r = [],
      n = (t = function (t) {
    for (var e = [], o = 0, r = t.length; o < r;) {
      var n = t.charCodeAt(o++);

      if (n >= 55296 && n <= 56319 && o < r) {
        var i = t.charCodeAt(o++);
        56320 == (64512 & i) ? e.push(((1023 & n) << 10) + (1023 & i) + 65536) : (e.push(n), o--);
      } else e.push(n);
    }

    return e;
  }(t)).length,
      i = 128,
      s = 0,
      a = 72;

  for (e = 0; e < t.length; e++) (o = t[e]) < 128 && r.push(cr(o));

  var f = r.length,
      u = f;

  for (f && r.push("-"); u < n;) {
    var c = 2147483647;

    for (e = 0; e < t.length; e++) (o = t[e]) >= i && o < c && (c = o);

    var l = u + 1;
    if (c - i > ur((2147483647 - s) / l)) throw RangeError(fr);

    for (s += (c - i) * l, i = c, e = 0; e < t.length; e++) {
      if ((o = t[e]) < i && ++s > 2147483647) throw RangeError(fr);

      if (o == i) {
        for (var p = s, m = 36;; m += 36) {
          var v = m <= a ? 1 : m >= a + 26 ? 26 : m - a;
          if (p < v) break;
          var k = p - v,
              h = 36 - v;
          r.push(cr(lr(v + k % h))), p = ur(k / h);
        }

        r.push(cr(lr(p))), a = pr(s, l, u == f), s = 0, ++u;
      }
    }

    ++s, ++i;
  }

  return r.join("");
},
    vr = function (t) {
  var e = nr(t);
  if ("function" != typeof e) throw TypeError(String(t) + " is not iterable");
  return I(e.call(t));
},
    kr = nt("fetch"),
    hr = nt("Headers"),
    yr = ee("iterator"),
    dr = tt.set,
    _r = tt.getterFor("URLSearchParams"),
    gr = tt.getterFor("URLSearchParamsIterator"),
    Sr = /\+/g,
    br = Array(4),
    Er = function (t) {
  return br[t - 1] || (br[t - 1] = RegExp("((?:%[\\da-f]{2}){" + t + "})", "gi"));
},
    Rr = function (t) {
  try {
    return decodeURIComponent(t);
  } catch (e) {
    return t;
  }
},
    $r = function (t) {
  var e = t.replace(Sr, " "),
      o = 4;

  try {
    return decodeURIComponent(e);
  } catch (t) {
    for (; o;) e = e.replace(Er(o--), Rr);

    return e;
  }
},
    Ar = /[!'()~]|%20/g,
    wr = {
  "!": "%21",
  "'": "%27",
  "(": "%28",
  ")": "%29",
  "~": "%7E",
  "%20": "+"
},
    Ir = function (t) {
  return wr[t];
},
    Tr = function (t) {
  return encodeURIComponent(t).replace(Ar, Ir);
},
    xr = function (t, e) {
  if (e) for (var o, r, n = e.split("&"), i = 0; i < n.length;) (o = n[i++]).length && (r = o.split("="), t.push({
    key: $r(r.shift()),
    value: $r(r.join("="))
  }));
},
    Or = function (t) {
  this.entries.length = 0, xr(this.entries, t);
},
    Lr = function (t, e) {
  if (t < e) throw TypeError("Not enough arguments");
},
    Mr = go(function (t, e) {
  dr(this, {
    type: "URLSearchParamsIterator",
    iterator: vr(_r(t).entries),
    kind: e
  });
}, "Iterator", function () {
  var t = gr(this),
      e = t.kind,
      o = t.iterator.next(),
      r = o.value;
  return o.done || (o.value = "keys" === e ? r.key : "values" === e ? r.value : [r.key, r.value]), o;
}),
    Pr = function () {
  qo(this, Pr, "URLSearchParams");
  var t,
      e,
      o,
      r,
      n,
      i,
      s,
      a,
      f,
      u = arguments.length > 0 ? arguments[0] : void 0,
      c = this,
      l = [];
  if (dr(c, {
    type: "URLSearchParams",
    entries: l,
    updateURL: function () {},
    updateSearchParams: Or
  }), void 0 !== u) if (y(u)) {
    if ("function" == typeof (t = nr(u))) for (o = (e = t.call(u)).next; !(r = o.call(e)).done;) {
      if ((s = (i = (n = vr(I(r.value))).next).call(n)).done || (a = i.call(n)).done || !i.call(n).done) throw TypeError("Expected sequence with length 2");
      l.push({
        key: s.value + "",
        value: a.value + ""
      });
    } else for (f in u) S(u, f) && l.push({
      key: f,
      value: u[f] + ""
    });
  } else xr(l, "string" == typeof u ? "?" === u.charAt(0) ? u.slice(1) : u : u + "");
},
    Ur = Pr.prototype;

!function (t, e, o) {
  for (var r in e) et(t, r, e[r], o);
}(Ur, {
  append: function (t, e) {
    Lr(arguments.length, 2);

    var o = _r(this);

    o.entries.push({
      key: t + "",
      value: e + ""
    }), o.updateURL();
  },
  delete: function (t) {
    Lr(arguments.length, 1);

    for (var e = _r(this), o = e.entries, r = t + "", n = 0; n < o.length;) o[n].key === r ? o.splice(n, 1) : n++;

    e.updateURL();
  },
  get: function (t) {
    Lr(arguments.length, 1);

    for (var e = _r(this).entries, o = t + "", r = 0; r < e.length; r++) if (e[r].key === o) return e[r].value;

    return null;
  },
  getAll: function (t) {
    Lr(arguments.length, 1);

    for (var e = _r(this).entries, o = t + "", r = [], n = 0; n < e.length; n++) e[n].key === o && r.push(e[n].value);

    return r;
  },
  has: function (t) {
    Lr(arguments.length, 1);

    for (var e = _r(this).entries, o = t + "", r = 0; r < e.length;) if (e[r++].key === o) return !0;

    return !1;
  },
  set: function (t, e) {
    Lr(arguments.length, 1);

    for (var o, r = _r(this), n = r.entries, i = !1, s = t + "", a = e + "", f = 0; f < n.length; f++) (o = n[f]).key === s && (i ? n.splice(f--, 1) : (i = !0, o.value = a));

    i || n.push({
      key: s,
      value: a
    }), r.updateURL();
  },
  sort: function () {
    var t,
        e,
        o,
        r = _r(this),
        n = r.entries,
        i = n.slice();

    for (n.length = 0, o = 0; o < i.length; o++) {
      for (t = i[o], e = 0; e < o; e++) if (n[e].key > t.key) {
        n.splice(e, 0, t);
        break;
      }

      e === o && n.push(t);
    }

    r.updateURL();
  },
  forEach: function (t) {
    for (var e, o = _r(this).entries, r = Yo(t, arguments.length > 1 ? arguments[1] : void 0, 3), n = 0; n < o.length;) r((e = o[n++]).value, e.key, this);
  },
  keys: function () {
    return new Mr(this, "keys");
  },
  values: function () {
    return new Mr(this, "values");
  },
  entries: function () {
    return new Mr(this, "entries");
  }
}, {
  enumerable: !0
}), et(Ur, yr, Ur.entries), et(Ur, "toString", function () {
  for (var t, e = _r(this).entries, o = [], r = 0; r < e.length;) t = e[r++], o.push(Tr(t.key) + "=" + Tr(t.value));

  return o.join("&");
}, {
  enumerable: !0
}), ho(Pr, "URLSearchParams"), Tt({
  global: !0,
  forced: !Go
}, {
  URLSearchParams: Pr
}), Go || "function" != typeof kr || "function" != typeof hr || Tt({
  global: !0,
  enumerable: !0,
  forced: !0
}, {
  fetch: function (t) {
    var e,
        o,
        r,
        n = [t];
    return arguments.length > 1 && (y(e = arguments[1]) && (o = e.body, "URLSearchParams" === or(o) && ((r = e.headers ? new hr(e.headers) : new hr()).has("content-type") || r.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"), e = Je(e, {
      body: c(0, String(o)),
      headers: c(0, r)
    }))), n.push(e)), kr.apply(this, n);
  }
});

var Nr,
    Cr = {
  URLSearchParams: Pr,
  getState: _r
},
    Dr = ue.codeAt,
    jr = n.URL,
    Fr = Cr.URLSearchParams,
    Gr = Cr.getState,
    qr = tt.set,
    Hr = tt.getterFor("URL"),
    Br = Math.floor,
    Wr = Math.pow,
    Yr = /[A-Za-z]/,
    Xr = /[\d+-.A-Za-z]/,
    Zr = /\d/,
    Kr = /^(0x|0X)/,
    Vr = /^[0-7]+$/,
    zr = /^\d+$/,
    Qr = /^[\dA-Fa-f]+$/,
    Jr = /[\0\t\n\r #%/:?@[\\]]/,
    tn = /[\0\t\n\r #/:?@[\\]]/,
    en = /^[\u0000-\u001F ]+|[\u0000-\u001F ]+$/g,
    on = /[\t\n\r]/g,
    rn = function (t, e) {
  var o, r, n;

  if ("[" == e.charAt(0)) {
    if ("]" != e.charAt(e.length - 1)) return "Invalid host";
    if (!(o = sn(e.slice(1, -1)))) return "Invalid host";
    t.host = o;
  } else if (vn(t)) {
    if (e = function (t) {
      var e,
          o,
          r = [],
          n = t.toLowerCase().replace(ar, ".").split(".");

      for (e = 0; e < n.length; e++) o = n[e], r.push(sr.test(o) ? "xn--" + mr(o) : o);

      return r.join(".");
    }(e), Jr.test(e)) return "Invalid host";
    if (null === (o = nn(e))) return "Invalid host";
    t.host = o;
  } else {
    if (tn.test(e)) return "Invalid host";

    for (o = "", r = ir(e), n = 0; n < r.length; n++) o += pn(r[n], fn);

    t.host = o;
  }
},
    nn = function (t) {
  var e,
      o,
      r,
      n,
      i,
      s,
      a,
      f = t.split(".");
  if (f.length && "" == f[f.length - 1] && f.pop(), (e = f.length) > 4) return t;

  for (o = [], r = 0; r < e; r++) {
    if ("" == (n = f[r])) return t;
    if (i = 10, n.length > 1 && "0" == n.charAt(0) && (i = Kr.test(n) ? 16 : 8, n = n.slice(8 == i ? 1 : 2)), "" === n) s = 0;else {
      if (!(10 == i ? zr : 8 == i ? Vr : Qr).test(n)) return t;
      s = parseInt(n, i);
    }
    o.push(s);
  }

  for (r = 0; r < e; r++) if (s = o[r], r == e - 1) {
    if (s >= Wr(256, 5 - e)) return null;
  } else if (s > 255) return null;

  for (a = o.pop(), r = 0; r < o.length; r++) a += o[r] * Wr(256, 3 - r);

  return a;
},
    sn = function (t) {
  var e,
      o,
      r,
      n,
      i,
      s,
      a,
      f = [0, 0, 0, 0, 0, 0, 0, 0],
      u = 0,
      c = null,
      l = 0,
      p = function () {
    return t.charAt(l);
  };

  if (":" == p()) {
    if (":" != t.charAt(1)) return;
    l += 2, c = ++u;
  }

  for (; p();) {
    if (8 == u) return;

    if (":" != p()) {
      for (e = o = 0; o < 4 && Qr.test(p());) e = 16 * e + parseInt(p(), 16), l++, o++;

      if ("." == p()) {
        if (0 == o) return;
        if (l -= o, u > 6) return;

        for (r = 0; p();) {
          if (n = null, r > 0) {
            if (!("." == p() && r < 4)) return;
            l++;
          }

          if (!Zr.test(p())) return;

          for (; Zr.test(p());) {
            if (i = parseInt(p(), 10), null === n) n = i;else {
              if (0 == n) return;
              n = 10 * n + i;
            }
            if (n > 255) return;
            l++;
          }

          f[u] = 256 * f[u] + n, 2 != ++r && 4 != r || u++;
        }

        if (4 != r) return;
        break;
      }

      if (":" == p()) {
        if (l++, !p()) return;
      } else if (p()) return;

      f[u++] = e;
    } else {
      if (null !== c) return;
      l++, c = ++u;
    }
  }

  if (null !== c) for (s = u - c, u = 7; 0 != u && s > 0;) a = f[u], f[u--] = f[c + s - 1], f[c + --s] = a;else if (8 != u) return;
  return f;
},
    an = function (t) {
  var e, o, r, n;

  if ("number" == typeof t) {
    for (e = [], o = 0; o < 4; o++) e.unshift(t % 256), t = Br(t / 256);

    return e.join(".");
  }

  if ("object" == typeof t) {
    for (e = "", r = function (t) {
      for (var e = null, o = 1, r = null, n = 0, i = 0; i < 8; i++) 0 !== t[i] ? (n > o && (e = r, o = n), r = null, n = 0) : (null === r && (r = i), ++n);

      return n > o && (e = r, o = n), e;
    }(t), o = 0; o < 8; o++) n && 0 === t[o] || (n && (n = !1), r === o ? (e += o ? ":" : "::", n = !0) : (e += t[o].toString(16), o < 7 && (e += ":")));

    return "[" + e + "]";
  }

  return t;
},
    fn = {},
    un = Wo({}, fn, {
  " ": 1,
  '"': 1,
  "<": 1,
  ">": 1,
  "`": 1
}),
    cn = Wo({}, un, {
  "#": 1,
  "?": 1,
  "{": 1,
  "}": 1
}),
    ln = Wo({}, cn, {
  "/": 1,
  ":": 1,
  ";": 1,
  "=": 1,
  "@": 1,
  "[": 1,
  "\\": 1,
  "]": 1,
  "^": 1,
  "|": 1
}),
    pn = function (t, e) {
  var o = Dr(t, 0);
  return o > 32 && o < 127 && !S(e, t) ? t : encodeURIComponent(t);
},
    mn = {
  ftp: 21,
  file: null,
  http: 80,
  https: 443,
  ws: 80,
  wss: 443
},
    vn = function (t) {
  return S(mn, t.scheme);
},
    kn = function (t) {
  return "" != t.username || "" != t.password;
},
    hn = function (t) {
  return !t.host || t.cannotBeABaseURL || "file" == t.scheme;
},
    yn = function (t, e) {
  var o;
  return 2 == t.length && Yr.test(t.charAt(0)) && (":" == (o = t.charAt(1)) || !e && "|" == o);
},
    dn = function (t) {
  var e;
  return t.length > 1 && yn(t.slice(0, 2)) && (2 == t.length || "/" === (e = t.charAt(2)) || "\\" === e || "?" === e || "#" === e);
},
    _n = function (t) {
  var e = t.path,
      o = e.length;
  !o || "file" == t.scheme && 1 == o && yn(e[0], !0) || e.pop();
},
    gn = function (t) {
  return "." === t || "%2e" === t.toLowerCase();
},
    Sn = {},
    bn = {},
    En = {},
    Rn = {},
    $n = {},
    An = {},
    wn = {},
    In = {},
    Tn = {},
    xn = {},
    On = {},
    Ln = {},
    Mn = {},
    Pn = {},
    Un = {},
    Nn = {},
    Cn = {},
    Dn = {},
    jn = {},
    Fn = {},
    Gn = {},
    qn = function (t, e, o, r) {
  var n,
      i,
      s,
      a,
      f,
      u = o || Sn,
      c = 0,
      l = "",
      p = !1,
      m = !1,
      v = !1;

  for (o || (t.scheme = "", t.username = "", t.password = "", t.host = null, t.port = null, t.path = [], t.query = null, t.fragment = null, t.cannotBeABaseURL = !1, e = e.replace(en, "")), e = e.replace(on, ""), n = ir(e); c <= n.length;) {
    switch (i = n[c], u) {
      case Sn:
        if (!i || !Yr.test(i)) {
          if (o) return "Invalid scheme";
          u = En;
          continue;
        }

        l += i.toLowerCase(), u = bn;
        break;

      case bn:
        if (i && (Xr.test(i) || "+" == i || "-" == i || "." == i)) l += i.toLowerCase();else {
          if (":" != i) {
            if (o) return "Invalid scheme";
            l = "", u = En, c = 0;
            continue;
          }

          if (o && (vn(t) != S(mn, l) || "file" == l && (kn(t) || null !== t.port) || "file" == t.scheme && !t.host)) return;
          if (t.scheme = l, o) return void (vn(t) && mn[t.scheme] == t.port && (t.port = null));
          l = "", "file" == t.scheme ? u = Pn : vn(t) && r && r.scheme == t.scheme ? u = Rn : vn(t) ? u = In : "/" == n[c + 1] ? (u = $n, c++) : (t.cannotBeABaseURL = !0, t.path.push(""), u = jn);
        }
        break;

      case En:
        if (!r || r.cannotBeABaseURL && "#" != i) return "Invalid scheme";

        if (r.cannotBeABaseURL && "#" == i) {
          t.scheme = r.scheme, t.path = r.path.slice(), t.query = r.query, t.fragment = "", t.cannotBeABaseURL = !0, u = Gn;
          break;
        }

        u = "file" == r.scheme ? Pn : An;
        continue;

      case Rn:
        if ("/" != i || "/" != n[c + 1]) {
          u = An;
          continue;
        }

        u = Tn, c++;
        break;

      case $n:
        if ("/" == i) {
          u = xn;
          break;
        }

        u = Dn;
        continue;

      case An:
        if (t.scheme = r.scheme, i == Nr) t.username = r.username, t.password = r.password, t.host = r.host, t.port = r.port, t.path = r.path.slice(), t.query = r.query;else if ("/" == i || "\\" == i && vn(t)) u = wn;else if ("?" == i) t.username = r.username, t.password = r.password, t.host = r.host, t.port = r.port, t.path = r.path.slice(), t.query = "", u = Fn;else {
          if ("#" != i) {
            t.username = r.username, t.password = r.password, t.host = r.host, t.port = r.port, t.path = r.path.slice(), t.path.pop(), u = Dn;
            continue;
          }

          t.username = r.username, t.password = r.password, t.host = r.host, t.port = r.port, t.path = r.path.slice(), t.query = r.query, t.fragment = "", u = Gn;
        }
        break;

      case wn:
        if (!vn(t) || "/" != i && "\\" != i) {
          if ("/" != i) {
            t.username = r.username, t.password = r.password, t.host = r.host, t.port = r.port, u = Dn;
            continue;
          }

          u = xn;
        } else u = Tn;

        break;

      case In:
        if (u = Tn, "/" != i || "/" != l.charAt(c + 1)) continue;
        c++;
        break;

      case Tn:
        if ("/" != i && "\\" != i) {
          u = xn;
          continue;
        }

        break;

      case xn:
        if ("@" == i) {
          p && (l = "%40" + l), p = !0, s = ir(l);

          for (var k = 0; k < s.length; k++) {
            var h = s[k];

            if (":" != h || v) {
              var y = pn(h, ln);
              v ? t.password += y : t.username += y;
            } else v = !0;
          }

          l = "";
        } else if (i == Nr || "/" == i || "?" == i || "#" == i || "\\" == i && vn(t)) {
          if (p && "" == l) return "Invalid authority";
          c -= ir(l).length + 1, l = "", u = On;
        } else l += i;

        break;

      case On:
      case Ln:
        if (o && "file" == t.scheme) {
          u = Nn;
          continue;
        }

        if (":" != i || m) {
          if (i == Nr || "/" == i || "?" == i || "#" == i || "\\" == i && vn(t)) {
            if (vn(t) && "" == l) return "Invalid host";
            if (o && "" == l && (kn(t) || null !== t.port)) return;
            if (a = rn(t, l)) return a;
            if (l = "", u = Cn, o) return;
            continue;
          }

          "[" == i ? m = !0 : "]" == i && (m = !1), l += i;
        } else {
          if ("" == l) return "Invalid host";
          if (a = rn(t, l)) return a;
          if (l = "", u = Mn, o == Ln) return;
        }

        break;

      case Mn:
        if (!Zr.test(i)) {
          if (i == Nr || "/" == i || "?" == i || "#" == i || "\\" == i && vn(t) || o) {
            if ("" != l) {
              var d = parseInt(l, 10);
              if (d > 65535) return "Invalid port";
              t.port = vn(t) && d === mn[t.scheme] ? null : d, l = "";
            }

            if (o) return;
            u = Cn;
            continue;
          }

          return "Invalid port";
        }

        l += i;
        break;

      case Pn:
        if (t.scheme = "file", "/" == i || "\\" == i) u = Un;else {
          if (!r || "file" != r.scheme) {
            u = Dn;
            continue;
          }

          if (i == Nr) t.host = r.host, t.path = r.path.slice(), t.query = r.query;else if ("?" == i) t.host = r.host, t.path = r.path.slice(), t.query = "", u = Fn;else {
            if ("#" != i) {
              dn(n.slice(c).join("")) || (t.host = r.host, t.path = r.path.slice(), _n(t)), u = Dn;
              continue;
            }

            t.host = r.host, t.path = r.path.slice(), t.query = r.query, t.fragment = "", u = Gn;
          }
        }
        break;

      case Un:
        if ("/" == i || "\\" == i) {
          u = Nn;
          break;
        }

        r && "file" == r.scheme && !dn(n.slice(c).join("")) && (yn(r.path[0], !0) ? t.path.push(r.path[0]) : t.host = r.host), u = Dn;
        continue;

      case Nn:
        if (i == Nr || "/" == i || "\\" == i || "?" == i || "#" == i) {
          if (!o && yn(l)) u = Dn;else if ("" == l) {
            if (t.host = "", o) return;
            u = Cn;
          } else {
            if (a = rn(t, l)) return a;
            if ("localhost" == t.host && (t.host = ""), o) return;
            l = "", u = Cn;
          }
          continue;
        }

        l += i;
        break;

      case Cn:
        if (vn(t)) {
          if (u = Dn, "/" != i && "\\" != i) continue;
        } else if (o || "?" != i) {
          if (o || "#" != i) {
            if (i != Nr && (u = Dn, "/" != i)) continue;
          } else t.fragment = "", u = Gn;
        } else t.query = "", u = Fn;

        break;

      case Dn:
        if (i == Nr || "/" == i || "\\" == i && vn(t) || !o && ("?" == i || "#" == i)) {
          if (".." === (f = (f = l).toLowerCase()) || "%2e." === f || ".%2e" === f || "%2e%2e" === f ? (_n(t), "/" == i || "\\" == i && vn(t) || t.path.push("")) : gn(l) ? "/" == i || "\\" == i && vn(t) || t.path.push("") : ("file" == t.scheme && !t.path.length && yn(l) && (t.host && (t.host = ""), l = l.charAt(0) + ":"), t.path.push(l)), l = "", "file" == t.scheme && (i == Nr || "?" == i || "#" == i)) for (; t.path.length > 1 && "" === t.path[0];) t.path.shift();
          "?" == i ? (t.query = "", u = Fn) : "#" == i && (t.fragment = "", u = Gn);
        } else l += pn(i, cn);

        break;

      case jn:
        "?" == i ? (t.query = "", u = Fn) : "#" == i ? (t.fragment = "", u = Gn) : i != Nr && (t.path[0] += pn(i, fn));
        break;

      case Fn:
        o || "#" != i ? i != Nr && ("'" == i && vn(t) ? t.query += "%27" : t.query += "#" == i ? "%23" : pn(i, fn)) : (t.fragment = "", u = Gn);
        break;

      case Gn:
        i != Nr && (t.fragment += pn(i, un));
    }

    c++;
  }
},
    Hn = function (t) {
  var e,
      o,
      r = qo(this, Hn, "URL"),
      n = arguments.length > 1 ? arguments[1] : void 0,
      i = String(t),
      a = qr(r, {
    type: "URL"
  });
  if (void 0 !== n) if (n instanceof Hn) e = Hr(n);else if (o = qn(e = {}, String(n))) throw TypeError(o);
  if (o = qn(a, i, null, e)) throw TypeError(o);
  var f = a.searchParams = new Fr(),
      u = Gr(f);
  u.updateSearchParams(a.query), u.updateURL = function () {
    a.query = String(f) || null;
  }, s || (r.href = Wn.call(r), r.origin = Yn.call(r), r.protocol = Xn.call(r), r.username = Zn.call(r), r.password = Kn.call(r), r.host = Vn.call(r), r.hostname = zn.call(r), r.port = Qn.call(r), r.pathname = Jn.call(r), r.search = ti.call(r), r.searchParams = ei.call(r), r.hash = oi.call(r));
},
    Bn = Hn.prototype,
    Wn = function () {
  var t = Hr(this),
      e = t.scheme,
      o = t.username,
      r = t.password,
      n = t.host,
      i = t.port,
      s = t.path,
      a = t.query,
      f = t.fragment,
      u = e + ":";
  return null !== n ? (u += "//", kn(t) && (u += o + (r ? ":" + r : "") + "@"), u += an(n), null !== i && (u += ":" + i)) : "file" == e && (u += "//"), u += t.cannotBeABaseURL ? s[0] : s.length ? "/" + s.join("/") : "", null !== a && (u += "?" + a), null !== f && (u += "#" + f), u;
},
    Yn = function () {
  var t = Hr(this),
      e = t.scheme,
      o = t.port;
  if ("blob" == e) try {
    return new Hn(e.path[0]).origin;
  } catch (t) {
    return "null";
  }
  return "file" != e && vn(t) ? e + "://" + an(t.host) + (null !== o ? ":" + o : "") : "null";
},
    Xn = function () {
  return Hr(this).scheme + ":";
},
    Zn = function () {
  return Hr(this).username;
},
    Kn = function () {
  return Hr(this).password;
},
    Vn = function () {
  var t = Hr(this),
      e = t.host,
      o = t.port;
  return null === e ? "" : null === o ? an(e) : an(e) + ":" + o;
},
    zn = function () {
  var t = Hr(this).host;
  return null === t ? "" : an(t);
},
    Qn = function () {
  var t = Hr(this).port;
  return null === t ? "" : String(t);
},
    Jn = function () {
  var t = Hr(this),
      e = t.path;
  return t.cannotBeABaseURL ? e[0] : e.length ? "/" + e.join("/") : "";
},
    ti = function () {
  var t = Hr(this).query;
  return t ? "?" + t : "";
},
    ei = function () {
  return Hr(this).searchParams;
},
    oi = function () {
  var t = Hr(this).fragment;
  return t ? "#" + t : "";
},
    ri = function (t, e) {
  return {
    get: t,
    set: e,
    configurable: !0,
    enumerable: !0
  };
};

if (s && Xe(Bn, {
  href: ri(Wn, function (t) {
    var e = Hr(this),
        o = String(t),
        r = qn(e, o);
    if (r) throw TypeError(r);
    Gr(e.searchParams).updateSearchParams(e.query);
  }),
  origin: ri(Yn),
  protocol: ri(Xn, function (t) {
    var e = Hr(this);
    qn(e, String(t) + ":", Sn);
  }),
  username: ri(Zn, function (t) {
    var e = Hr(this),
        o = ir(String(t));

    if (!hn(e)) {
      e.username = "";

      for (var r = 0; r < o.length; r++) e.username += pn(o[r], ln);
    }
  }),
  password: ri(Kn, function (t) {
    var e = Hr(this),
        o = ir(String(t));

    if (!hn(e)) {
      e.password = "";

      for (var r = 0; r < o.length; r++) e.password += pn(o[r], ln);
    }
  }),
  host: ri(Vn, function (t) {
    var e = Hr(this);
    e.cannotBeABaseURL || qn(e, String(t), On);
  }),
  hostname: ri(zn, function (t) {
    var e = Hr(this);
    e.cannotBeABaseURL || qn(e, String(t), Ln);
  }),
  port: ri(Qn, function (t) {
    var e = Hr(this);
    hn(e) || ("" == (t = String(t)) ? e.port = null : qn(e, t, Mn));
  }),
  pathname: ri(Jn, function (t) {
    var e = Hr(this);
    e.cannotBeABaseURL || (e.path = [], qn(e, t + "", Cn));
  }),
  search: ri(ti, function (t) {
    var e = Hr(this);
    "" == (t = String(t)) ? e.query = null : ("?" == t.charAt(0) && (t = t.slice(1)), e.query = "", qn(e, t, Fn)), Gr(e.searchParams).updateSearchParams(e.query);
  }),
  searchParams: ri(ei),
  hash: ri(oi, function (t) {
    var e = Hr(this);
    "" != (t = String(t)) ? ("#" == t.charAt(0) && (t = t.slice(1)), e.fragment = "", qn(e, t, Gn)) : e.fragment = null;
  })
}), et(Bn, "toJSON", function () {
  return Wn.call(this);
}, {
  enumerable: !0
}), et(Bn, "toString", function () {
  return Wn.call(this);
}, {
  enumerable: !0
}), jr) {
  var ni = jr.createObjectURL,
      ii = jr.revokeObjectURL;
  ni && et(Hn, "createObjectURL", function (t) {
    return ni.apply(jr, arguments);
  }), ii && et(Hn, "revokeObjectURL", function (t) {
    return ii.apply(jr, arguments);
  });
}

ho(Hn, "URL"), Tt({
  global: !0,
  forced: !Go,
  sham: !s
}, {
  URL: Hn
});

const si = () => "https://api.iextrading.com/1.0/";

exports._URL_PREFIX = si;

let ai = t => `https://cloud.iexapis.com/${t}/`,
    fi = () => "https://sandbox.iexapis.com/stable/";

exports._URL_PREFIX_CLOUD_SANDBOX = fi;
exports._URL_PREFIX_CLOUD = ai;
const ui = ai,
      ci = fi,
      li = "https://ws-api.iextrading.com",
      pi = 443;
exports._SIO_PORT = pi;
exports._SIO_URL_PREFIX = li;

let mi = (t, e, o, r) => `https://cloud-sse.iexapis.com/${t}/${e}?symbols=${o}&token=${r}`;

exports._SSE_URL_PREFIX = mi;
const vi = mi;

let ki = (t, e, o) => `https://cloud-sse.iexapis.com/${t}/${e}?token=${o}`;

exports._SSE_URL_PREFIX_ALL = ki;
const hi = ki;

let yi = (t, e, o, r) => `https://cloud-sse.iexapis.com/${t}/deep?symbols=${e}&channels=${o}&token=${r}`;

exports._SSE_DEEP_URL_PREFIX = yi;
const di = yi;

let _i = (t, e, o, r) => `https://sandbox-sse.iexapis.com/stable/${e}?symbols=${o}&token=${r}`;

exports._SSE_URL_PREFIX_SANDBOX = _i;
const gi = _i;

let Si = (t, e) => `https://sandbox-sse.iexapis.com/stable/${t}?token=${e}`;

exports._SSE_URL_PREFIX_ALL_SANDBOX = Si;
const bi = Si;

let Ei = (t, e, o) => `https://sandbox-sse.iexapis.com/stable/deep?symbols=${t}&channels=${e}&token=${o}`;

exports._SSE_DEEP_URL_PREFIX_SANDBOX = Ei;

const Ri = Ei,
      $i = async t => {
  const {
    base_url: e,
    url: o,
    token: r = "",
    version: n = "stable",
    filter: i = "",
    format: s = "json"
  } = t;
  let a;
  const f = new URL(`${e(n)}${o}`);
  return f.searchParams.append("token", r), i && f.searchParams.append("filter", i), "csv" === s || "text" === s ? (f.searchParams.append("format", s), a = "test/plain") : "schema" === s ? (f.searchParams.append("schema", !0), a = "application/json") : a = "application/json", fetch(f.href, {
    method: "GET",
    headers: {
      "Content-Type": a
    }
  }).then(async t => {
    if (t.ok) {
      if ("json" === s) return t.json();

      if ("schema" === s) {
        const e = t.json();
        return Array.isArray(e) ? e[0] : e;
      }

      return t.text();
    }

    throw ge(`Response ${t.status} - ${await t.text()}`);
  });
},
      Ai = async t => {
  const {
    base_url: e,
    url: o,
    data: r = {},
    token: n = "",
    version: i = "stable",
    token_in_params: s = !0,
    format: a = "json"
  } = t,
        f = new URL(`${e(i)}${o}`);
  return s && f.searchParams.append("token", n), fetch(f, {
    method: "POST",
    body: s ? {
      token: n,
      ...r
    } : {},
    headers: {
      "Content-Type": "application/json"
    }
  }).then(async t => {
    if (t.ok) return "json" === a ? t.json() : t.text();
    throw ge(`Response ${t.status} - ${await t.text()}`);
  });
},
      wi = async t => {
  const {
    base_url: e,
    url: o,
    token: r = "",
    version: n = "stable",
    format: i = "json"
  } = t,
        s = new URL(`${e(n)}${o}`);
  return s.searchParams.append("token", r), fetch(s, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json"
    }
  }).then(async t => {
    if (t.ok) return "json" === i ? t.json() : t.text();
    throw ge(`Response ${t.status} - ${await t.text()}`);
  });
},
      Ii = (t, e, o = !1) => {
  const r = new EventSource(t),
        n = e || console.log;
  return r.accrued = [], r.onmessage = async t => {
    const e = JSON.parse(t.data);
    await n(e), o && r.accrued.push(e);
  }, r;
},
      Ti = ({
  url: t = "",
  env: e = ""
} = {}) => {
  e ? (exports._URL_PREFIX_CLOUD = ai = t => `https://cloud.${e}.iexapis.com/${t}/`, exports._URL_PREFIX_CLOUD = ai = t => `https://cloud.${e}.iexapis.com/${t}/`, exports._URL_PREFIX_CLOUD_SANDBOX = fi = () => `https://sandbox.${e}.iexapis.com/stable/`, exports._SSE_URL_PREFIX = mi = (t, o, r, n) => `https://cloud-sse.${e}.iexapis.com/${t}/${o}?symbols=${r}&token=${n}`, exports._SSE_URL_PREFIX_ALL = ki = (t, o, r) => `https://cloud-sse.${e}.iexapis.com/${t}/${o}?token=${r}`, exports._SSE_DEEP_URL_PREFIX = yi = (t, o, r, n) => `https://cloud-sse.${e}.iexapis.com/${t}/deep?symbols=${o}&channels=${r}&token=${n}`, exports._SSE_URL_PREFIX_SANDBOX = _i = (t, o, r, n) => `https://sandbox-sse.${e}.iexapis.com/stable/${o}?symbols=${r}&token=${n}`, exports._SSE_URL_PREFIX_ALL_SANDBOX = Si = (t, o) => `https://sandbox-sse.${e}.iexapis.com/stable/${t}?token=${o}`, exports._SSE_DEEP_URL_PREFIX_SANDBOX = Ei = (t, o, r) => `https://sandbox-sse.${e}.iexapis.com/stable/deep?symbols=${t}&channels=${o}&token=${r}`) : t ? (exports._URL_PREFIX_CLOUD = ai = () => t, exports._URL_PREFIX_CLOUD_SANDBOX = fi = () => t) : (exports._URL_PREFIX_CLOUD = ai = ui, exports._URL_PREFIX_CLOUD_SANDBOX = fi = ci, exports._SSE_URL_PREFIX = mi = vi, exports._SSE_URL_PREFIX_ALL = ki = hi, exports._SSE_DEEP_URL_PREFIX = yi = di, exports._SSE_URL_PREFIX_SANDBOX = _i = gi, exports._SSE_URL_PREFIX_ALL_SANDBOX = Si = bi, exports._SSE_DEEP_URL_PREFIX_SANDBOX = Ei = Ri);
},
      xi = async t => {
  const {
    url: e,
    token: o = "",
    version: r = ""
  } = t;
  return o ? "sandbox" === r ? (t => $i({
    base_url: fi,
    ...t
  }))(t) : (t => $i({
    base_url: ai,
    ...t
  }))(t) : (() => {
    throw ge("Old IEX API is deprecated. For a free API token, sign up at https://iexcloud.io");
  })();
},
      Oi = async t => {
  const {
    version: e = ""
  } = t;
  return "sandbox" === e ? (t => Ai({
    base_url: fi,
    ...t
  }))(t) : (t => Ai({
    base_url: ai,
    ...t
  }))(t);
},
      Li = t => {
  const {
    version: e = ""
  } = t;
  return "sandbox" === e ? (t => wi({
    base_url: fi,
    ...t
  }))(t) : (t => wi({
    base_url: ai,
    ...t
  }))(t);
};

exports._delete = Li;
exports._post = Oi;
exports._get = xi;
exports.overrideUrl = Ti;
exports._streamSSE = Ii;

function Mi(t, e, o) {
  return e in t ? Object.defineProperty(t, e, {
    value: o,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : t[e] = o, t;
}

class Pi {
  constructor(t = {}) {
    const {
      api_token: e = (process ? process.env.IEX_TOKEN : null) || "",
      version: o = "v1"
    } = t;
    if (this._token = e, !this._token) throw ge("API Token missing or not in environment (IEX_TOKEN)");
    if (["beta", "stable", "v1", "sandbox"].indexOf(o) < 0) throw ge("Unrecognized api version: {}".format(o));
    if (this._token.startsWith("T") && "sandbox" !== o) throw ge("Using test key but attempting to connect to non-sandbox environment");
    this._version = o, this.premium = new Pi.premium(), this.premiumfiles = new Pi.premiumfiles(), this.premium._token = this._token, this.premium._version = this._version;
  }

}

exports.Client = Pi;
Mi(Pi, "premium", class {}), Mi(Pi, "premiumfiles", class {});

const Ui = (t, e, o, r) => (Ge(e), Oi({
  url: `account/messagebudget?totalMessages=${t}`,
  token: e,
  version: o,
  format: r
}));

exports.messageBudget = Ui;

Pi.prototype.messageBudget = function (t, e) {
  return Ui(t, this._token, this._version, e);
};

const Ni = (t, e, o) => (Ge(t), xi({
  url: "account/metadata",
  token: t,
  version: e,
  format: o
}));

exports.metadata = Ni;

Pi.prototype.metadata = function (t) {
  return Ni(this._token, this._version, t);
};

const Ci = (t = !1, e = "", o = "") => {
  if (Ge(e), "boolean" != typeof t) throw ge(`allow must be boolean, got ${typeof t} (${t})`);
  return Oi({
    url: `account/messagebudget?allow=${t}`,
    token: e,
    version: o
  });
};

exports.payAsYouGo = Ci;

Pi.prototype.payAsYouGo = function (t) {
  return Ni(t, this._token, this._version);
};

const Di = (t, e, o, r) => {
  if (Ge(e), t) {
    if (Te.indexOf(t) < 0) throw ge(`Type must be defined or in ${Te}`);
    return xi({
      url: `account/usage/${t}`,
      token: e,
      version: o,
      format: r
    });
  }

  return xi({
    url: "account/usage",
    token: e,
    version: o,
    format: r
  });
};

exports.usage = Di;

Pi.prototype.usage = function (t, e) {
  return Di(t, this._token, this._version, e);
};

const ji = (t, e, o) => xi({
  url: "status",
  token: t,
  version: e,
  format: o
});

exports.status = ji;

Pi.prototype.status = function (t) {
  return ji(this._token, this._version, t);
};

const Fi = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), xi(o ? {
  url: `stock/${t}/sentiment/${e}/${Ce(o)}`,
  token: r,
  version: n,
  filter: i,
  format: s
} : {
  url: `stock/${t}/sentiment/${e}/`,
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.sentiment = Fi;

Pi.prototype.sentiment = function (t, e = "daily", o = null, {
  filter: r,
  format: n
} = {}) {
  return Fi(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Gi = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${t}/ceo-compensation/`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.ceoCompensation = Gi;

Pi.prototype.ceoCompensation = function (t, {
  filter: e,
  format: o
} = {}) {
  return Gi(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const qi = ({
  symbol: t,
  key: e
} = {}, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => (je(t || "market"), xi(e ? {
  url: `data-points/${t || "market"}/${e}`,
  token: o,
  version: r,
  filter: n,
  format: i
} : {
  url: `data-points/${t || "market"}`,
  token: o,
  version: r,
  filter: n,
  format: i
}));

exports.points = qi;

Pi.prototype.points = function ({
  symbol: t,
  key: e
} = {}, {
  filter: o,
  format: r
} = {}) {
  return qi({
    symbol: t,
    key: e
  }, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Hi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DCOILWTICO"
}, {
  token: t,
  version: e
}),
      Bi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DCOILBRENTEU"
}, {
  token: t,
  version: e
}),
      Wi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DHHNGSP"
}, {
  token: t,
  version: e
}),
      Yi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DHOILNYH"
}, {
  token: t,
  version: e
}),
      Xi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DJFUELUSGULF"
}, {
  token: t,
  version: e
}),
      Zi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "GASDESW"
}, {
  token: t,
  version: e
}),
      Ki = ({
  token: t,
  version: e
} = {}) => qi({
  key: "GASREGCOVW"
}, {
  token: t,
  version: e
}),
      Vi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "GASMIDCOVW"
}, {
  token: t,
  version: e
}),
      zi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "GASPRMCOVW"
}, {
  token: t,
  version: e
}),
      Qi = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DPROPANEMBTX"
}, {
  token: t,
  version: e
});

exports.propane = Qi;
exports.gasprm = zi;
exports.gasmid = Vi;
exports.gasreg = Ki;
exports.diesel = Zi;
exports.jet = Xi;
exports.heatoil = Yi;
exports.natgas = Wi;
exports.brent = Bi;
exports.wti = Hi;
Pi.prototype.wti = function () {
  return Hi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.brent = function () {
  return Bi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.natgas = function () {
  return Wi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.heatoil = function () {
  return Yi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.jet = function () {
  return Xi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.diesel = function () {
  return Zi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.gasreg = function () {
  return Ki({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.gasmid = function () {
  return Vi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.gasprm = function () {
  return zi({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.propane = function () {
  return Qi({
    token: this._token,
    version: this._version
  });
};

const Ji = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi({
  url: `crypto/${t}/book`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.cryptoBook = Ji;

Pi.prototype.cryptoBook = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ji(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ts = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi({
  url: `crypto/${t}/price`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.cryptoPrice = ts;

Pi.prototype.cryptoPrice = function (t, {
  filter: e,
  format: o
} = {}) {
  return ts(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const es = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi({
  url: `crypto/${t}/quote`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.cryptoQuote = es;

Pi.prototype.cryptoQuote = function (t, {
  filter: e,
  format: o
} = {}) {
  return es(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const os = ({
  token: t,
  version: e
} = {}) => qi({
  key: "MORTGAGE30US"
}, {
  token: t,
  version: e
}),
      rs = ({
  token: t,
  version: e
} = {}) => qi({
  key: "MORTGAGE15US"
}, {
  token: t,
  version: e
}),
      ns = ({
  token: t,
  version: e
} = {}) => qi({
  key: "MORTGAGE5US"
}, {
  token: t,
  version: e
}),
      is = ({
  token: t,
  version: e
} = {}) => qi({
  key: "FEDFUNDS"
}, {
  token: t,
  version: e
}),
      ss = ({
  token: t,
  version: e
} = {}) => qi({
  key: "TERMCBCCALLNS"
}, {
  token: t,
  version: e
}),
      as = ({
  token: t,
  version: e
} = {}) => qi({
  key: "MMNRNJ"
}, {
  token: t,
  version: e
}),
      fs = ({
  token: t,
  version: e
} = {}) => qi({
  key: "MMNRJD"
}, {
  token: t,
  version: e
}),
      us = ({
  token: t,
  version: e
} = {}) => qi({
  key: "A191RL1Q225SBEA"
}, {
  token: t,
  version: e
}),
      cs = ({
  token: t,
  version: e
} = {}) => qi({
  key: "INDPRO"
}, {
  token: t,
  version: e
}),
      ls = ({
  token: t,
  version: e
} = {}) => qi({
  key: "CPIAUCSL"
}, {
  token: t,
  version: e
}),
      ps = ({
  token: t,
  version: e
} = {}) => qi({
  key: "PAYEMS"
}, {
  token: t,
  version: e
}),
      ms = ({
  token: t,
  version: e
} = {}) => qi({
  key: "HOUST"
}, {
  token: t,
  version: e
}),
      vs = ({
  token: t,
  version: e
} = {}) => qi({
  key: "UNRATE"
}, {
  token: t,
  version: e
}),
      ks = ({
  token: t,
  version: e
} = {}) => qi({
  key: "TOTALSA"
}, {
  token: t,
  version: e
}),
      hs = ({
  token: t,
  version: e
} = {}) => qi({
  key: "RECPROUSM156N"
}, {
  token: t,
  version: e
}),
      ys = ({
  token: t,
  version: e
} = {}) => qi({
  key: "IC4WSA"
}, {
  token: t,
  version: e
}),
      ds = ({
  token: t,
  version: e
} = {}) => qi({
  key: "WRMFSL"
}, {
  token: t,
  version: e
}),
      _s = ({
  token: t,
  version: e
} = {}) => qi({
  key: "WIMFSL"
}, {
  token: t,
  version: e
});

exports.retailMoney = _s;
exports.institutionalMoney = ds;
exports.initialClaims = ys;
exports.recessionProb = hs;
exports.vehicles = ks;
exports.unemployment = vs;
exports.housing = ms;
exports.payroll = ps;
exports.cpi = ls;
exports.indpro = cs;
exports.gdp = us;
exports.cdj = fs;
exports.cdnj = as;
exports.creditcard = ss;
exports.fedfunds = is;
exports.us5 = ns;
exports.us15 = rs;
exports.us30 = os;
Pi.prototype.us30 = function () {
  return os({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.us15 = function () {
  return rs({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.us5 = function () {
  return ns({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.fedfunds = function () {
  return is({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.creditcard = function () {
  return ss({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.cdnj = function () {
  return as({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.cdj = function () {
  return fs({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.gdp = function () {
  return us({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.indpro = function () {
  return cs({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.cpi = function () {
  return ls({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.payroll = function () {
  return ps({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.housing = function () {
  return ms({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.unemployment = function () {
  return vs({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.vehicles = function () {
  return ks({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.recessionProb = function () {
  return hs({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.initialClaims = function () {
  return ys({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.institutionalMoney = function () {
  return ds({
    token: this._token,
    version: this._version
  });
}, Pi.prototype.retailMoney = function () {
  return _s({
    token: this._token,
    version: this._version
  });
};

const gs = ({
  id: t,
  symbol: e,
  date: o
} = {}, {
  token: r,
  version: n
} = {}) => xi(t ? e && o ? {
  url: `files/download/${t}?symbol=${e}&date=${Ce(o)}`,
  token: r,
  version: n
} : {
  url: `files/info/${t}`,
  token: r,
  version: n
} : {
  url: "files",
  token: r,
  version: n
}),
      Ss = async ({
  id: t,
  symbol: e,
  date: o
} = {}, {
  token: r,
  version: n
} = {}) => {
  const i = await gs({
    id: t,
    symbol: e,
    date: o
  }, {
    token: r,
    version: n
  }),
        s = `data:application/pdf,${encodeURI(i)}`,
        a = document.createElement("a");
  a.href = s, a.download = `${t}-${e}-${o}.pdf`, document.body.appendChild(a), a.click(), document.body.removeChild(a);
};

exports.download = Ss;
exports.files = gs;
Pi.prototype.files = function ({
  id: t,
  symbol: e,
  date: o
} = {}) {
  return gs({
    id: t,
    symbol: e,
    date: o
  }, {
    token: this._token,
    version: this._version
  });
}, Pi.prototype.download = function ({
  id: t,
  symbol: e,
  date: o
} = {}) {
  return Ss({
    id: t,
    symbol: e,
    date: o
  }, {
    token: this._token,
    version: this._version
  });
};

const bs = ({
  symbols: t
} = {}, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `/fx/latest?symbols=${Ue(t).join(",")}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "/fx/latest",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.latestFX = bs;

Pi.prototype.latestFX = function ({
  symbols: t
} = {}, {
  filter: e,
  format: o
} = {}) {
  return bs({
    symbols: t
  }, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Es = ({
  symbols: t,
  amount: e
} = {}, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => xi(t ? {
  url: `/fx/convert?symbols=${Ue(t).join(",")}&amount=${e || ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
} : {
  url: `/fx/convert?amount=${e || ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.convertFX = Es;

Pi.prototype.convertFX = function ({
  symbols: t,
  amount: e
} = {}, {
  filter: o,
  format: r
} = {}) {
  return Es({
    symbols: t,
    amount: e
  }, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Rs = ({
  symbols: t,
  from: e,
  to: o,
  on: r,
  last: n,
  first: i
} = {}, {
  token: s,
  version: a,
  filter: f,
  format: u
} = {}) => {
  let c = "/fx/historical?";
  return t && (c += `symbols=${Ue(t).join(",")}&`), e && (c += `from=${Ce(e)}&`), o && (c += `to=${Ce(o)}&`), r && (c += `to=${Ce(r)}&`), n && (c += `last=${n.toString()}&`), i && (c += `last=${i.toString()}&`), xi({
    url: c,
    token: s,
    version: a,
    filter: f,
    format: u
  });
};

exports.historicalFX = Rs;

Pi.prototype.historicalFX = function ({
  symbols: t,
  from: e,
  to: o,
  on: r,
  last: n,
  first: i
} = {}, {
  filter: s,
  format: a
} = {}) {
  return Rs({
    symbols: t,
    from: e,
    to: o,
    on: r,
    last: n,
    first: i
  }, {
    token: this._token,
    version: this._version,
    filter: s,
    format: a
  });
};

const $s = ({
  id: t,
  key: e,
  subkey: o
} = {}, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => {
  let a = "metadata/time-series";
  return !t && e && (t = "any"), t && (a += `/${t}`, e && (a += `/${e}`, o && (a += `/${o}`))), xi({
    url: a,
    token: r,
    version: n,
    filter: i,
    format: s
  });
};

exports.queryMetadata = $s;

Pi.prototype.queryMetadata = function ({
  id: t,
  key: e,
  subkey: o
} = {}, {
  filter: r,
  format: n
} = {}) {
  return $s({
    id: t,
    key: e,
    subkey: o
  }, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const As = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `/stock/${t}/options`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.optionExpirations = As;

Pi.prototype.optionExpirations = function (t, {
  filter: e,
  format: o
} = {}) {
  return As(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ws = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), xi(o ? {
  url: `stock/${t}/options/${e}/${o}`,
  token: r,
  version: n,
  filter: i,
  format: s
} : {
  url: `stock/${t}/options/${e}`,
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.options = ws;

Pi.prototype.options = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return ws(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Is = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "time-series",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.timeSeriesInventory = Is;

Pi.prototype.timeSeriesInventory = function ({
  filter: t,
  format: e
} = {}) {
  return Is({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Ts = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => {
  const {
    id: i = "",
    key: s = "",
    subkey: a = "",
    range: f = "",
    limit: u = 1,
    subattribute: c = "",
    dateField: l = "",
    from: p = "",
    to: m = "",
    on: v = "",
    last: k = 0,
    first: h = 0
  } = t || {};
  if (!i) return Is({
    token: e,
    version: o,
    filter: r,
    format: n
  });
  let y = `time-series/${i}`;
  return s && (y += `/${qe(s)}`), a && (y += `/${qe(a)}`), y += "?", f && (y += `range=${De(f)}&`), k || m && p || (y += `limit=${u}&`), c && (y += `subattribute=${c}&`), l && (y += `dateField=${l}&`), p && (y += `from=${Ce(p)}&`), m && (y += `to=${Ce(m)}&`), v && (y += `on=${Ce(v)}&`), k && (y += `last=${k}&`), h && (y += `first=${h}&`), xi({
    url: y,
    token: e,
    version: o,
    filter: r,
    format: n
  });
};

exports.timeSeries = Ts;

Pi.prototype.timeSeries = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ts(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const xs = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      Os = (t, e, o, r, n, ...i) => xs("PREMIUM_AUDIT_ANALYTICS_DIRECTOR_OFFICER_CHANGES", t, e, o, r, n, ...i);

exports.directorAndOfficerChangesAuditAnalytics = Os;

Pi.premium.prototype.directorAndOfficerChanges = function (t, e, o, ...r) {
  return Os(t, this._token, this._version, e, o, ...r);
};

const Ls = (t, e, o, r, n, ...i) => xs("PREMIUM_AUDIT_ANALYTICS_ACCOUNTING_QUALITY_RISK_MATRIX", t, e, o, r, n, ...i);

exports.accountingQualityAndRiskMatrixAuditAnalytics = Ls;

Pi.premium.prototype.accountingQualityAndRiskMatrix = function (t, e, o, ...r) {
  return Ls(t, this._token, this._version, e, o, ...r);
};

const Ms = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      Ps = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_SENTIMENT_30_DAYS", t, e, o, r, n, ...i);

exports.thirtyDaySentimentBrain = Ps;

Pi.premium.prototype.thirtyDaySentiment = function (t, e, o, ...r) {
  return Ps(t, this._token, this._version, e, o, ...r);
};

const Us = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_SENTIMENT_7_DAYS", t, e, o, r, n, ...i);

exports.sevenDaySentimentBrain = Us;

Pi.premium.prototype.sevenDaySentiment = function (t, e, o, ...r) {
  return Us(t, this._token, this._version, e, o, ...r);
};

const Ns = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_RANKING_21_DAYS", t, e, o, r, n, ...i);

exports.twentyOneDayMLReturnRankingBrain = Ns;

Pi.premium.prototype.twentyOneDayMLReturnRanking = function (t, e, o, ...r) {
  return Ns(t, this._token, this._version, e, o, ...r);
};

const Cs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_RANKING_10_DAYS", t, e, o, r, n, ...i);

exports.tenDayMLReturnRankingBrain = Cs;

Pi.premium.prototype.tenDayMLReturnRanking = function (t, e, o, ...r) {
  return Cs(t, this._token, this._version, e, o, ...r);
};

const Ds = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_RANKING_5_DAYS", t, e, o, r, n, ...i);

exports.fiveDayMLReturnRankingBrain = Ds;

Pi.premium.prototype.fiveDayMLReturnRanking = function (t, e, o, ...r) {
  return Ds(t, this._token, this._version, e, o, ...r);
};

const js = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_RANKING_3_DAYS", t, e, o, r, n, ...i);

exports.threeDayMLReturnRankingBrain = js;

Pi.premium.prototype.threeDayMLReturnRanking = function (t, e, o, ...r) {
  return js(t, this._token, this._version, e, o, ...r);
};

const Fs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_RANKING_2_DAYS", t, e, o, r, n, ...i);

exports.twoDayMLReturnRankingBrain = Fs;

Pi.premium.prototype.twoDayMLReturnRanking = function (t, e, o, ...r) {
  return Fs(t, this._token, this._version, e, o, ...r);
};

const Gs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_LANGUAGE_METRICS_ALL", t, e, o, r, n, ...i);

exports.languageMetricsOnCompanyFilingsAllBrain = Gs;

Pi.premium.prototype.languageMetricsOnCompanyFilingsAll = function (t, e, o, ...r) {
  return Gs(t, this._token, this._version, e, o, ...r);
};

const qs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_LANGUAGE_METRICS_10K", t, e, o, r, n, ...i);

exports.languageMetricsOnCompanyFilingsBrain = qs;

Pi.premium.prototype.languageMetricsOnCompanyFilings = function (t, e, o, ...r) {
  return qs(t, this._token, this._version, e, o, ...r);
};

const Hs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_LANGUAGE_DIFFERENCES_ALL", t, e, o, r, n, ...i);

exports.languageMetricsOnCompanyFilingsDifferenceAllBrain = Hs;

Pi.premium.prototype.languageMetricsOnCompanyFilingsDifferenceAll = function (t, e, o, ...r) {
  return Hs(t, this._token, this._version, e, o, ...r);
};

const Bs = (t, e, o, r, n, ...i) => Ms("PREMIUM_BRAIN_LANGUAGE_DIFFERENCES_10K", t, e, o, r, n, ...i);

exports.languageMetricsOnCompanyFilingsDifferenceBrain = Bs;

Pi.premium.prototype.languageMetricsOnCompanyFilingsDifference = function (t, e, o, ...r) {
  return Bs(t, this._token, this._version, e, o, ...r);
};

const Ws = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      Ys = (t, e, o, r, n, ...i) => Ws("PREMIUM_EXTRACT_ALPHA_CAM", t, e, o, r, n, ...i);

exports.cam1ExtractAlpha = Ys;

Pi.premium.prototype.cam1 = function (t, e, o, ...r) {
  return Ys(t, this._token, this._version, e, o, ...r);
};

const Xs = (t, e, o, r, n, ...i) => (i.subkey = 1, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgCFPBComplaintsExtractAlpha = Xs;

Pi.premium.prototype.esgCFPBComplaints = function (t, e, o, ...r) {
  return Xs(t, this._token, this._version, e, o, ...r);
};

const Zs = (t, e, o, r, n, ...i) => (i.subkey = 5, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgCPSCRecallsExtractAlpha = Zs;

Pi.premium.prototype.esgCPSCRecalls = function (t, e, o, ...r) {
  return Zs(t, this._token, this._version, e, o, ...r);
};

const Ks = (t, e, o, r, n, ...i) => (i.subkey = 8, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgDOLVisaApplicationsExtractAlpha = Ks;

Pi.premium.prototype.esgDOLVisaApplications = function (t, e, o, ...r) {
  return Ks(t, this._token, this._version, e, o, ...r);
};

const Vs = (t, e, o, r, n, ...i) => (i.subkey = 2, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgEPAEnforcementsExtractAlpha = Vs;

Pi.premium.prototype.esgEPAEnforcements = function (t, e, o, ...r) {
  return Vs(t, this._token, this._version, e, o, ...r);
};

const zs = (t, e, o, r, n, ...i) => (i.subkey = 3, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgEPAMilestonesExtractAlpha = zs;

Pi.premium.prototype.esgEPAMilestones = function (t, e, o, ...r) {
  return zs(t, this._token, this._version, e, o, ...r);
};

const Qs = (t, e, o, r, n, ...i) => (i.subkey = 7, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgFECIndividualCampaingContributionsExtractAlpha = Qs;

Pi.premium.prototype.esgFECIndividualCampaingContributions = function (t, e, o, ...r) {
  return Qs(t, this._token, this._version, e, o, ...r);
};

const Js = (t, e, o, r, n, ...i) => (i.subkey = 4, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgOSHAInspectionsExtractAlpha = Js;

Pi.premium.prototype.esgOSHAInspections = function (t, e, o, ...r) {
  return Js(t, this._token, this._version, e, o, ...r);
};

const ta = (t, e, o, r, n, ...i) => (i.subkey = 6, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgSenateLobbyingExtractAlpha = ta;

Pi.premium.prototype.esgSenateLobbying = function (t, e, o, ...r) {
  return ta(t, this._token, this._version, e, o, ...r);
};

const ea = (t, e, o, r, n, ...i) => (i.subkey = 9, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgUSASpendingExtractAlpha = ea;

Pi.premium.prototype.esgUSASpending = function (t, e, o, ...r) {
  return ea(t, this._token, this._version, e, o, ...r);
};

const oa = (t, e, o, r, n, ...i) => (i.subkey = 10, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgUSPTOPatentApplicationsExtractAlpha = oa;

Pi.premium.prototype.esgUSPTOPatentApplications = function (t, e, o, ...r) {
  return oa(t, this._token, this._version, e, o, ...r);
};

const ra = (t, e, o, r, n, ...i) => (i.subkey = 11, Ws("PREMIUM_EXTRACT_ALPHA_ESG", t, e, o, r, n, ...i));

exports.esgUSPTOPatentGrantsExtractAlpha = ra;

Pi.premium.prototype.esgUSPTOPatentGrants = function (t, e, o, ...r) {
  return ra(t, this._token, this._version, e, o, ...r);
};

const na = (t, e, o, r, n, ...i) => Ws("PREMIUM_EXTRACT_ALPHA_TM", t, e, o, r, n, ...i);

exports.tacticalModel1ExtractAlpha = na;

Pi.premium.prototype.tacticalModel1 = function (t, e, o, ...r) {
  return na(t, this._token, this._version, e, o, ...r);
};

const ia = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      sa = (t, e, o, r, n, ...i) => ia("PREMIUM_FRAUD_FACTORS_SIMILARITY_INDEX", t, e, o, r, n, ...i);

exports.similarityIndexFraudFactors = sa;

Pi.premium.prototype.similarityIndex = function (t, e, o, ...r) {
  return sa(t, this._token, this._version, e, o, ...r);
};

const aa = (t, e, o, r, n, ...i) => ia("PREMIUM_FRAUD_FACTORS_NON_TIMELY_FILINGS", t, e, o, r, n, ...i);

exports.nonTimelyFilingsFraudFactors = aa;

Pi.premium.prototype.nonTimelyFilings = function (t, e, o, ...r) {
  return aa(t, this._token, this._version, e, o, ...r);
};

const fa = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      ua = (t, e, o, r, n, ...i) => fa("PREMIUM_KAVOUT_KSCORE", t, e, o, r, n, ...i);

exports.kScoreKavout = ua;

Pi.premium.prototype.kScore = function (t, e, o, ...r) {
  return ua(t, this._token, this._version, e, o, ...r);
};

const ca = (t, e, o, r, n, ...i) => fa("PREMIUM_KAVOUT_KSCORE_A_SHARES", t, e, o, r, n, ...i);

exports.kScoreChinaKavout = ca;

Pi.premium.prototype.kScoreChina = function (t, e, o, ...r) {
  return ca(t, this._token, this._version, e, o, ...r);
};

const la = (t, e, o, r) => {
  if (!t || !e) throw new ge("symbol and date required");
  return gs("VALUENGINE_REPORT", t);
},
      pa = (t, e, o, r) => {
  if (!t || !e) throw new ge("symbol and date required");
  return Ss("VALUENGINE_REPORT", t);
};

exports.downloadReportNewConstructs = pa;
exports.reportNewConstructs = la;
Pi.premiumfiles.prototype.newConstructs = function (t, e) {
  return la(t, e, this._token, this._version);
}, Pi.premiumfiles.prototype.downloadNewConstructs = function (t, e) {
  return pa(t, e, this._token, this._version);
};

const ma = (t, e, o, r, n, ...i) => ((t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o))("PREMIUM_PRECISION_ALPHA_PRICE_DYNAMICS", t, e, o, r, n, ...i);

exports.priceDynamicsPrecisionAlpha = ma;

Pi.premium.prototype.priceDynamics = function (t, e, o, ...r) {
  return ma(t, this._token, this._version, e, o, ...r);
};

const va = async (t, e, o, r, n, i, s) => {
  if (je(t), ["daily", "minute"].indexOf(e || "daily") < 0) throw new ge("`type` must be either daily or minute");
  let a = `stock/${t}/sentiment/${e || "daily"}`;
  return o && (a += `/${o = Ce(o)}`), xi({
    url: a,
    token: r,
    version: n,
    filter: i,
    format: s
  });
};

exports.socialSentimentStockTwits = va;

Pi.premium.prototype.socialSentiment = function (t, e, o, r, n) {
  return va(t, e, o, this._token, this._version, r, n);
};

const ka = (t, e, o, r) => {
  if (!t || !e) throw new ge("symbol and date required");
  return gs("VALUENGINE_REPORT", t);
},
      ha = (t, e, o, r) => {
  if (!t || !e) throw new ge("symbol and date required");
  return Ss("VALUENGINE_REPORT", t);
};

exports.downloadStockReportvaluEngine = ha;
exports.stockReportValuEngine = ka;
Pi.premiumfiles.prototype.valuEngine = function (t, e) {
  return ka(t, e, this._token, this._version);
}, Pi.premiumfiles.prototype.downloadValuEngine = function (t, e) {
  return ha(t, e, this._token, this._version);
};

const ya = (t, e, o, r, n, i, ...s) => Ts({
  id: t,
  key: e,
  ...s
}, o),
      da = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_ANALYST_DAY", t, e, o, r, n, ...i);

exports.analystDaysWallStreetHorizon = da;

Pi.premium.prototype.analystDays = function (t, e, o, ...r) {
  return da(t, this._token, this._version, e, o, ...r);
};

const _a = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_BOARD_OF_DIRECTORS_MEETING", t, e, o, r, n, ...i);

exports.boardOfDirectorsMeetingWallStreetHorizon = _a;

Pi.premium.prototype.boardOfDirectorsMeeting = function (t, e, o, ...r) {
  return _a(t, this._token, this._version, e, o, ...r);
};

const ga = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_BUSINESS_UPDATE", t, e, o, r, n, ...i);

exports.businessUpdatesWallStreetHorizon = ga;

Pi.premium.prototype.businessUpdates = function (t, e, o, ...r) {
  return ga(t, this._token, this._version, e, o, ...r);
};

const Sa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_BUYBACK", t, e, o, r, n, ...i);

exports.buybacksWallStreetHorizon = Sa;

Pi.premium.prototype.buybacks = function (t, e, o, ...r) {
  return Sa(t, this._token, this._version, e, o, ...r);
};

const ba = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_CAPITAL_MARKETS_DAY", t, e, o, r, n, ...i);

exports.capitalMarketsDayWallStreetHorizon = ba;

Pi.premium.prototype.capitalMarketsDay = function (t, e, o, ...r) {
  return ba(t, this._token, this._version, e, o, ...r);
};

const Ea = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_COMPANY_TRAVEL", t, e, o, r, n, ...i);

exports.companyTravelWallStreetHorizon = Ea;

Pi.premium.prototype.companyTravel = function (t, e, o, ...r) {
  return Ea(t, this._token, this._version, e, o, ...r);
};

const Ra = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_FILING_DUE_DATE", t, e, o, r, n, ...i);

exports.filingDueDatesWallStreetHorizon = Ra;

Pi.premium.prototype.filingDueDates = function (t, e, o, ...r) {
  return Ra(t, this._token, this._version, e, o, ...r);
};

const $a = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_FISCAL_QUARTER_END_DATE", t, e, o, r, n, ...i);

exports.fiscalQuarterEndWallStreetHorizon = $a;

Pi.premium.prototype.fiscalQuarterEnd = function (t, e, o, ...r) {
  return $a(t, this._token, this._version, e, o, ...r);
};

const Aa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_FORUM", t, e, o, r, n, ...i);

exports.forumWallStreetHorizon = Aa;

Pi.premium.prototype.forum = function (t, e, o, ...r) {
  return Aa(t, this._token, this._version, e, o, ...r);
};

const wa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_GENERAL_CONFERENCE", t, e, o, r, n, ...i);

exports.generalConferenceWallStreetHorizon = wa;

Pi.premium.prototype.generalConference = function (t, e, o, ...r) {
  return wa(t, this._token, this._version, e, o, ...r);
};

const Ia = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_STOCK_SPECIFIC_FDA_ADVISORY_COMMITTEE_MEETING", t, e, o, r, n, ...i);

exports.fdaAdvisoryCommitteeMeetingsWallStreetHorizon = Ia;

Pi.premium.prototype.fdaAdvisoryCommitteeMeetings = function (t, e, o, ...r) {
  return Ia(t, this._token, this._version, e, o, ...r);
};

const Ta = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_HOLIDAYS", t, e, o, r, n, ...i);

exports.holidaysWallStreetHorizon = Ta;

Pi.premium.prototype.holidays = function (t, e, o, ...r) {
  return Ta(t, this._token, this._version, e, o, ...r);
};

const xa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_INDEX_CHANGE", t, e, o, r, n, ...i);

exports.indexChangesWallStreetHorizon = xa;

Pi.premium.prototype.indexChanges = function (t, e, o, ...r) {
  return xa(t, this._token, this._version, e, o, ...r);
};

const Oa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_INITIAL_PUBLIC_OFFERING", t, e, o, r, n, ...i);

exports.iposWallStreetHorizon = Oa;

Pi.premium.prototype.ipos = function (t, e, o, ...r) {
  return Oa(t, this._token, this._version, e, o, ...r);
};

const La = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_LEGAL_ACTIONS", t, e, o, r, n, ...i);

exports.legalActionsWallStreetHorizon = La;

Pi.premium.prototype.legalActions = function (t, e, o, ...r) {
  return La(t, this._token, this._version, e, o, ...r);
};

const Ma = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_MERGER_ACQUISITIONS", t, e, o, r, n, ...i);

exports.mergersAndAcquisitionsWallStreetHorizon = Ma;

Pi.premium.prototype.mergersAndAcquisitions = function (t, e, o, ...r) {
  return Ma(t, this._token, this._version, e, o, ...r);
};

const Pa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_PRODUCT_EVENTS", t, e, o, r, n, ...i);

exports.productEventsWallStreetHorizon = Pa;

Pi.premium.prototype.productEvents = function (t, e, o, ...r) {
  return Pa(t, this._token, this._version, e, o, ...r);
};

const Ua = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_RD_DAY", t, e, o, r, n, ...i);

exports.researchAndDevelopmentDaysWallStreetHorizon = Ua;

Pi.premium.prototype.researchAndDevelopmentDays = function (t, e, o, ...r) {
  return Ua(t, this._token, this._version, e, o, ...r);
};

const Na = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_SAME_STORE_SALES", t, e, o, r, n, ...i);

exports.sameStoreSalesWallStreetHorizon = Na;

Pi.premium.prototype.sameStoreSales = function (t, e, o, ...r) {
  return Na(t, this._token, this._version, e, o, ...r);
};

const Ca = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_SECONDARY_OFFERING", t, e, o, r, n, ...i);

exports.secondaryOfferingsWallStreetHorizon = Ca;

Pi.premium.prototype.secondaryOfferings = function (t, e, o, ...r) {
  return Ca(t, this._token, this._version, e, o, ...r);
};

const Da = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_SEMINAR", t, e, o, r, n, ...i);

exports.seminarsWallStreetHorizon = Da;

Pi.premium.prototype.seminars = function (t, e, o, ...r) {
  return Da(t, this._token, this._version, e, o, ...r);
};

const ja = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_SHAREHOLDER_MEETING", t, e, o, r, n, ...i);

exports.shareholderMeetingsWallStreetHorizon = ja;

Pi.premium.prototype.shareholderMeetings = function (t, e, o, ...r) {
  return ja(t, this._token, this._version, e, o, ...r);
};

const Fa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_SUMMIT_MEETING", t, e, o, r, n, ...i);

exports.summitMeetingsWallStreetHorizon = Fa;

Pi.premium.prototype.summitMeetings = function (t, e, o, ...r) {
  return Fa(t, this._token, this._version, e, o, ...r);
};

const Ga = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_TRADE_SHOW", t, e, o, r, n, ...i);

exports.tradeShowsWallStreetHorizon = Ga;

Pi.premium.prototype.tradeShows = function (t, e, o, ...r) {
  return Ga(t, this._token, this._version, e, o, ...r);
};

const qa = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_WITCHING_HOURS", t, e, o, r, n, ...i);

exports.witchingHoursWallStreetHorizon = qa;

Pi.premium.prototype.witchingHours = function (t, e, o, ...r) {
  return qa(t, this._token, this._version, e, o, ...r);
};

const Ha = (t, e, o, r, n, ...i) => ya("PREMIUM_WALLSTREETHORIZON_WORKSHOP", t, e, o, r, n, ...i);

exports.workshopsWallStreetHorizon = Ha;

Pi.premium.prototype.workshops = function (t, e, o, ...r) {
  return Ha(t, this._token, this._version, e, o, ...r);
};

const Ba = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS30"
}, {
  token: t,
  version: e
});

exports.thirtyYear = Ba;

Pi.prototype.thirtyYear = function () {
  return Ba({
    token: this._token,
    version: this._version
  });
};

const Wa = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS20"
}, {
  token: t,
  version: e
});

exports.twentyYear = Wa;

Pi.prototype.twentyYear = function () {
  return Wa({
    token: this._token,
    version: this._version
  });
};

const Ya = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS10"
}, {
  token: t,
  version: e
});

exports.tenYear = Ya;

Pi.prototype.tenYear = function () {
  return Ya({
    token: this._token,
    version: this._version
  });
};

const Xa = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS5"
}, {
  token: t,
  version: e
});

exports.fiveYear = Xa;

Pi.prototype.fiveYear = function () {
  return Xa({
    token: this._token,
    version: this._version
  });
};

const Za = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS2"
}, {
  token: t,
  version: e
});

exports.twoYear = Za;

Pi.prototype.twoYear = function () {
  return Za({
    token: this._token,
    version: this._version
  });
};

const Ka = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS1"
}, {
  token: t,
  version: e
});

exports.oneYear = Ka;

Pi.prototype.oneYear = function () {
  return Ka({
    token: this._token,
    version: this._version
  });
};

const Va = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS6MO"
}, {
  token: t,
  version: e
});

exports.sixMonth = Va;

Pi.prototype.sixMonth = function () {
  return Ba({
    token: this._token,
    version: this._version
  });
};

const za = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS3MO"
}, {
  token: t,
  version: e
});

exports.threeMonth = za;

Pi.prototype.threeMonth = function () {
  return za({
    token: this._token,
    version: this._version
  });
};

const Qa = ({
  token: t,
  version: e
} = {}) => qi({
  key: "DGS1MO"
}, {
  token: t,
  version: e
});

exports.oneMonth = Qa;

Pi.prototype.oneMonth = function () {
  return Qa({
    token: this._token,
    version: this._version
  });
};

const Ja = ({
  type: t = "holiday",
  direction: e = "next",
  last: o = 1,
  startDate: r = null
} = {}, {
  token: n = "",
  version: i = "",
  filter: s = "",
  format: a = "json"
} = {}) => xi(r ? {
  url: `ref-data/us/dates/${t}/${e}/${o}/${Ce(r)}`,
  token: n,
  version: i,
  filter: s,
  format: a
} : {
  url: `ref-data/us/dates/${t}/${e}/${o.toString()}`,
  token: n,
  version: i,
  filter: s,
  format: a
}),
      tf = Ja;

exports.holidays = tf;
exports.calendar = Ja;
Pi.prototype.calendar = function ({
  type: t,
  direction: e,
  last: o,
  startDate: r
} = {}, {
  filter: n,
  format: i
} = {}) {
  return Ja({
    type: t,
    direction: e,
    last: o,
    startDate: r
  }, {
    token: this._token,
    version: this._version,
    filter: n,
    format: i
  });
}, Pi.prototype.holidays = function ({
  type: t,
  direction: e,
  last: o,
  startDate: r
} = {}, {
  filter: n,
  format: i
} = {}) {
  return Ja({
    type: t,
    direction: e,
    last: o,
    startDate: r
  }, {
    token: this._token,
    version: this._version,
    filter: n,
    format: i
  });
};

const ef = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/market/us/exchanges",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.exchanges = ef;

Pi.prototype.exchanges = function ({
  filter: t,
  format: e
} = {}) {
  return ef({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const of = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/exchanges",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.internationalExchanges = of;

Pi.prototype.internationalExchanges = function ({
  filter: t,
  format: e
} = {}) {
  return of({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const rf = (t, {
  token: e = "",
  version: o = "",
  filter: r = "",
  format: n = "json"
} = {}) => (je(t), xi({
  url: `ref-data/figi?figi=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.figi = rf;

Pi.prototype.figi = function (t, {
  filter: e,
  format: o
} = {}) {
  return rf(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const nf = (t, {
  token: e = "",
  version: o = "",
  filter: r = "",
  format: n = "json"
} = {}) => xi({
  url: `ref-data/isin?isin=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.isinLookup = nf;

Pi.prototype.isinLookup = function (t, {
  filter: e,
  format: o
} = {}) {
  return nf(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const sf = (t, {
  token: e = "",
  version: o = "",
  filter: r = "",
  format: n = "json"
} = {}) => xi({
  url: `ref-data/ric?ric=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.ricLookup = sf;

Pi.prototype.ricLookup = function (t, {
  filter: e,
  format: o
} = {}) {
  return sf(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const af = (t, {
  token: e = "",
  version: o = "",
  filter: r = "",
  format: n = "json"
} = {}) => xi({
  url: `search/${qe(t)}`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.search = af;

Pi.prototype.search = function (t, {
  filter: e,
  format: o
} = {}) {
  return af(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ff = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/sectors",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.sectors = ff;

Pi.prototype.sectors = function ({
  filter: t,
  format: e
} = {}) {
  return ff({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const uf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/tags",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.tags = uf;

Pi.prototype.tags = function ({
  filter: t,
  format: e
} = {}) {
  return uf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const cf = async t => (await t).map(t => t.symbol),
      lf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/crypto/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.cryptoSymbols = lf;

Pi.prototype.cryptoSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return lf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const pf = ({
  token: t,
  version: e
} = {}) => cf(lf({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.cryptoSymbolsList = pf;

Pi.prototype.cryptoSymbolsList = function () {
  return cf(lf({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const mf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.symbols = mf;

Pi.prototype.symbols = function ({
  filter: t,
  format: e
} = {}) {
  return mf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const vf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/otc/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.otcSymbols = vf;

Pi.prototype.otcSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return vf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const kf = ({
  region: t,
  exchange: e
} = {}, {
  token: o = "",
  version: r = "",
  filter: n = "",
  format: i = "json"
} = {}) => xi(t ? {
  url: `ref-data/region/${t}/symbols`,
  token: o,
  version: r,
  filter: n,
  format: i
} : e ? {
  url: `ref-data/exchange/${e}/symbols`,
  token: o,
  version: r,
  filter: n,
  format: i
} : {
  url: "ref-data/region/us/symbols",
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.internationalSymbols = kf;

Pi.prototype.internationalSymbols = function ({
  region: t,
  exchange: e
} = {}, {
  filter: o,
  format: r
} = {}) {
  return kf({
    region: t,
    exchange: e
  }, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const hf = ({
  token: t,
  version: e
} = {}) => cf(mf({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.symbolsList = hf;

Pi.prototype.symbolsList = function () {
  return cf(mf({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const yf = ({
  token: t,
  version: e
} = {}) => cf(vf({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.otcSymbolsList = yf;

Pi.prototype.otcSymbolsList = function () {
  return cf(vf({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const df = ({
  region: t,
  exchange: e
} = {}, {
  token: o,
  version: r
} = {}) => cf(kf({
  region: t,
  exchange: e
}, {
  token: o,
  version: r,
  filter: "symbol"
}));

exports.internationalSymbolsList = df;

Pi.prototype.internationalSymbolsList = function ({
  region: t,
  exchange: e
} = {}) {
  return cf(kf({
    region: t,
    exchange: e
  }, {
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const _f = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/mutual-funds/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.mutualFundSymbols = _f;

Pi.prototype.mutualFundSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return _f({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const gf = ({
  token: t,
  version: e
} = {}) => cf(_f({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.mutualFundSymbolsList = gf;

Pi.prototype.mutualFundSymbolsList = function () {
  return cf(_f({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const Sf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/futures/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.futuresSymbols = Sf;

Pi.prototype.futuresSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return Sf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const bf = ({
  token: t,
  version: e
} = {}) => cf(Sf({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.futuresSymbolsList = bf;

Pi.prototype.futuresSymbolsList = function () {
  return cf(Sf({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const Ef = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/fx/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.fxSymbols = Ef;

Pi.prototype.fxSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return Ef({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Rf = async ({
  token: t,
  version: e
} = {}) => {
  const o = await Ef({
    token: t,
    version: e
  }),
        r = [[], []];
  return o.currencies.forEach(t => {
    r[0].push(t.code);
  }), o.pairs.forEach(t => {
    r[1].push(t.fromCurrency + t.toCurrency);
  }), r;
};

exports.fxSymbolsList = Rf;

Pi.prototype.fxSymbolsList = function () {
  return Rf({
    token: this._token,
    version: this._version
  });
};

const $f = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/iex/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.iexSymbols = $f;

Pi.prototype.iexSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return $f({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Af = ({
  token: t,
  version: e
} = {}) => cf($f({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.iexSymbolsList = Af;

Pi.prototype.iexSymbolsList = function () {
  return cf($f({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const wf = ({
  token: t = "",
  version: e = "",
  filter: o = "",
  format: r = "json"
} = {}) => xi({
  url: "ref-data/options/symbols",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.optionsSymbols = wf;

Pi.prototype.optionsSymbols = function ({
  filter: t,
  format: e
} = {}) {
  return wf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const If = t => {
  const e = [];
  return Object.keys(t).forEach(o => {
    t[o].forEach(t => {
      e.push(`${o}-${t}`);
    });
  }), e;
},
      Tf = async ({
  token: t,
  version: e
} = {}) => If(await wf({
  token: t,
  version: e,
  filter: "symbol"
}));

exports.optionsSymbolsList = Tf;

Pi.prototype.optionsSymbolsList = async function () {
  return If(await wf({
    token: this._token,
    version: this._version,
    filter: "symbol"
  }));
};

const xf = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => (je(t), xi(t ? {
  url: `rules/lookup/${t}`,
  token: e,
  version: o,
  format: r
} : {
  url: "rules/schema",
  token: e,
  version: o,
  format: r
}));

exports.lookup = xf;

Pi.prototype.lookup = function (t, {
  format: e
}) {
  return xf(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const Of = ({
  token: t,
  version: e,
  format: o = "json"
} = {}) => xi({
  url: "rules/schema",
  token: t,
  version: e,
  format: o
});

exports.schema = Of;

Pi.prototype.schema = function ({
  format: t
} = {}) {
  return Of({
    token: this._token,
    version: this._version,
    format: t
  });
};

const Lf = (t, e, o, r, n, {
  token: i,
  version: s,
  format: a = "json"
} = {}) => {
  if ("any" !== (r = r || "any") && "all" !== r) throw new ge("Type must be in (any, all)");
  if (t.token = i, t.ruleSet = o, t.type = r, t.ruleName = e, void 0 === t.conditions) throw new ge("rule is missing `conditions` key!");
  if (void 0 === t.outputs) throw new ge("rule is missing `outputs` key!");
  return n && (t.id = n), Oi({
    url: "rules/create",
    json: t,
    token: i,
    version: s,
    token_in_params: !1,
    format: a
  });
};

exports.create = Lf;

Pi.prototype.create = function (t, e, o, r, n, {
  format: i
}) {
  return Lf(t, e, o, r, n, {
    token: this._token,
    version: this._version,
    format: i
  });
};

const Mf = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => Oi({
  url: "rules/pause",
  json: {
    ruleId: t,
    token: e
  },
  token: e,
  version: o,
  token_in_params: !1,
  format: r
});

exports.pause = Mf;

Pi.prototype.pause = function (t, {
  format: e
} = {}) {
  return Mf(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const Pf = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => Oi({
  url: "rules/resume",
  json: {
    ruleId: t,
    token: e
  },
  token: e,
  version: o,
  token_in_params: !1,
  format: r
});

exports.resume = Pf;

Pi.prototype.resume = function (t, {
  format: e
} = {}) {
  return Pf(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const Uf = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => Li({
  url: `rules/${t}`,
  token: e,
  version: o,
  format: r
});

exports.delete_ = Uf;

Pi.prototype.delete = function (t, {
  format: e
} = {}) {
  return Uf(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const Nf = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => xi({
  url: `rules/info/${t}`,
  token: e,
  version: o,
  format: r
});

exports.rule = Nf;

Pi.prototype.rule = function (t, {
  format: e
} = {}) {
  return Nf(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const Cf = ({
  token: t,
  version: e,
  format: o = "json"
} = {}) => xi({
  url: "rules",
  token: t,
  version: e,
  format: o
});

exports.rules = Cf;

Pi.prototype.rules = function ({
  format: t
} = {}) {
  return Cf({
    token: this._token,
    version: this._version,
    format: t
  });
};

const Df = (t, {
  token: e,
  version: o,
  format: r = "json"
} = {}) => xi({
  url: `rules/output/${t}`,
  token: e,
  version: o,
  format: r
});

exports.output = Df;

Pi.prototype.output = function (t, {
  format: e
} = {}) {
  return Df(t, {
    token: this._token,
    version: this._version,
    format: e
  });
};

const jf = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stats/intraday",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.systemStats = jf;

Pi.prototype.systemStats = function ({
  filter: t,
  format: e
} = {}) {
  return jf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Ff = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stats/recent",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.recent = Ff;

Pi.prototype.recent = function ({
  filter: t,
  format: e
} = {}) {
  return Ff({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Gf = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stats/records",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.records = Gf;

Pi.prototype.records = function ({
  filter: t,
  format: e
} = {}) {
  return Gf({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const qf = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `stats/historical?date=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "stats/historical",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.summary = qf;

Pi.prototype.summary = function (t, {
  filter: e,
  format: o
} = {}) {
  return qf(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Hf = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => xi(t ? {
  url: `stats/historical/daily?date=${t}`,
  token: o,
  version: r,
  filter: n,
  format: i
} : e ? {
  url: `stats/historical/daily?last=${e}`,
  token: o,
  version: r,
  filter: n,
  format: i
} : {
  url: "stats/historical/daily",
  token: o,
  version: r,
  filter: n
});

exports.daily = Hf;

Pi.prototype.daily = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Hf(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Bf = (t, {
  fields: e,
  range: o,
  last: r
} = {}, {
  token: n,
  version: i,
  filter: s,
  format: a
} = {}) => {
  if (o = o || "1m", r = r || 10, "string" == typeof (e = e || "quote") && (e = e.split(",")), e.forEach(t => {
    if (xe.indexOf(t) < 0) throw new ge(`Unrecognized batch request field: ${t}`);
  }), Ee.indexOf(o) < 0) throw new ge(`Unrecognized range argument: ${o}`);
  if ((t = qe(t)).split(",").length > 100) throw new ge("IEX will only handle up to 100 symbols at a time!");
  let f;
  return f = t.indexOf(",") < 0 ? `stock/${t}/batch?types=${e.join(",")}&range=${o}&last=${r}` : `stock/market/batch?symbols=${t}&types=${e.join(",")}&range=${o}&last=${r}`, xi({
    url: f,
    token: n,
    version: i,
    filter: s,
    format: a
  });
};

exports.batch = Bf;

Pi.prototype.batch = function (t, {
  fields: e,
  range: o,
  last: r
} = {}, {
  filter: n,
  format: i
} = {}) {
  return Bf(t, e, o, (this._token, this._version));
};

const Wf = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  if (je(t), Re.indexOf(e || "ytd") < 0) throw new ge("Timeframe not recognized");
  return xi({
    url: `stock/${qe(t)}/splits/${e || "ytd"}`,
    token: o,
    version: r,
    filter: n,
    format: i
  });
};

exports.stockSplits = Wf;

Pi.prototype.stockSplits = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Wf(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Yf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_bonus",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.bonusIssue = Yf;

Pi.prototype.bonusIssue = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Yf(t, e, o, {
    token: this._token,
    version: this._version,
    format: n,
    filter: r
  });
};

const Xf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_distribution",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.distribution = Xf;

Pi.prototype.distribution = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Xf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Zf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_dividends",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.dividends = Zf;

Pi.prototype.dividends = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Zf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Kf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_return_of_capital",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.returnOfCapital = Kf;

Pi.prototype.returnOfCapital = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Kf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Vf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_rights",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.rightsIssue = Vf;

Pi.prototype.rightsIssue = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Vf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const zf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_right_to_purchase",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.rightToPurchase = zf;

Pi.prototype.rightToPurchase = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return zf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Qf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_security_reclassification",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.securityReclassification = Qf;

Pi.prototype.securityReclassification = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Qf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const Jf = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_security_swap",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.securitySwap = Jf;

Pi.prototype.securitySwap = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return Jf(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const tu = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_spinoff",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.spinoff = tu;

Pi.prototype.spinoff = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return tu(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const eu = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), He(o), Ts({
  id: "advanced_splits",
  key: t,
  subkey: e || "",
  ...(o || {})
}, {
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.splits = eu;

Pi.prototype.splits = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return eu(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const ou = async (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), Fe(e || "quarter", o || 1), (await xi({
  url: `stock/${qe(t)}/balance-sheet?period=${e || "quarter"}&last=${o || 1}`,
  token: r,
  version: n,
  filter: i,
  format: s
}).balancesheet) || []);

exports.balanceSheet = ou;

Pi.prototype.balanceSheet = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return ou(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const ru = async (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), Fe(e || "quarter", o || 1), (await xi({
  url: `stock/${qe(t)}/cash-flow?period=${e || "quarter"}&last=${o || 1}`,
  token: r,
  version: n,
  filter: i,
  format: s
}).cashflow) || []);

exports.cashFlow = ru;

Pi.prototype.cashFlow = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return ru(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const nu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  if (je(t), Re.indexOf(e || "ytd") < 0) throw new ge("Timeframe not recognized");
  return xi({
    url: `stock/${qe(t)}/dividends/${e || "ytd"}`,
    token: o,
    version: r,
    filter: n,
    format: i
  });
};

exports.dividendsBasic = nu;

Pi.prototype.dividendsBasic = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return nu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const iu = async (t, e, o, r, {
  token: n,
  version: i,
  filter: s,
  format: a
} = {}) => (je(t), Fe(e || "quarter", o || 1), void 0 === r ? (await xi({
  url: `stock/${qe(t)}/earnings?period=${e || "quarter"}&last=${o || 1}`,
  token: n,
  version: i,
  filter: s,
  format: a
}).earnings) || [] : (await xi({
  url: `stock/${qe(t)}/earnings/${o || 1}/${r}?period=${e || "quarter"}`,
  token: n,
  version: i,
  filter: s,
  format: a
}).earnings) || []);

exports.earnings = iu;

Pi.prototype.earnings = function (t, e, o, r, {
  filter: n,
  format: i
} = {}) {
  return iu(t, e, o, r, {
    token: this._token,
    version: this._version,
    filter: n,
    format: i
  });
};

const su = async (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), Fe(e || "quarter", o || 1), (await xi({
  url: `stock/${qe(t)}/financials?period=${e || "quarter"}&last=${o || 1}`,
  token: r,
  version: n,
  filter: i,
  format: s
}).financials) || []);

exports.financials = su;

Pi.prototype.financials = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return su(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const au = async (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => (je(t), Fe(e || "quarter", 1), (await xi({
  url: `stock/${qe(t)}/fundamentals?period=${e || "quarter"}`,
  token: o,
  version: r,
  filter: n,
  format: i
}).fundamentals) || []);

exports.fundamentals = au;

Pi.prototype.fundamentals = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return au(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const fu = async (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), Fe(e || "quarter", o || 1), (await xi({
  url: `stock/${qe(t)}/income?period=${e || "quarter"}&last=${o || 1}`,
  token: r,
  version: n,
  filter: i,
  format: s
}).income) || []);

exports.incomeStatement = fu;

Pi.prototype.incomeStatement = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return fu(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const uu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => Ts({
  id: "REPORTED_FINANCIALS",
  key: t,
  subkey: "10-Q",
  ...(e || {})
}, {
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.tenQ = uu;

Pi.prototype.tenQ = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return uu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const cu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => Ts({
  id: "REPORTED_FINANCIALS",
  key: t,
  subkey: "10-K",
  ...(e || {})
}, {
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.tenK = cu;

Pi.prototype.tenK = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return cu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const lu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => Ts({
  id: "REPORTED_FINANCIALS",
  key: t,
  subkey: "20-F",
  ...(e || {})
}, {
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.twentyF = lu;

Pi.prototype.twentyF = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return lu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const pu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => Ts({
  id: "REPORTED_FINANCIALS",
  key: t,
  subkey: "40-F",
  ...(e || {})
}, {
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.fortyF = pu;

Pi.prototype.fortyF = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return pu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const mu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `tops?symbols=${Ue(t).join(",")}%2b`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "tops",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.iexTops = mu;

Pi.prototype.iexTops = function (t, {
  filter: e,
  format: o
} = {}) {
  return mu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const vu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `last?symbols=${Ue(t).join(",")}%2b`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "last",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.iexLast = vu;

Pi.prototype.iexLast = function (t, {
  filter: e,
  format: o
} = {}) {
  return vu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ku = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexDeep = ku;

Pi.prototype.iexDeep = function (t, {
  filter: e,
  format: o
} = {}) {
  return ku(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const hu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/auction?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/auction",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexAuction = hu;

Pi.prototype.iexAuction = function (t, {
  filter: e,
  format: o
} = {}) {
  return hu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const yu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/book?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/book",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexBook = yu;

Pi.prototype.iexBook = function (t, {
  filter: e,
  format: o
} = {}) {
  return yu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const du = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/op-halt-status?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/op-halt-status",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexOpHaltStatus = du;

Pi.prototype.iexOpHaltStatus = function (t, {
  filter: e,
  format: o
} = {}) {
  return du(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const _u = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/official-price?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/official-price",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexOfficialPrice = _u;

Pi.prototype.iexOfficialPrice = function (t, {
  filter: e,
  format: o
} = {}) {
  return _u(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const gu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/security-event?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/security-event",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexSecurityEvent = gu;

Pi.prototype.iexSecurityEvent = function (t, {
  filter: e,
  format: o
} = {}) {
  return gu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Su = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/ssr-status?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/ssr-status",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexSsrStatus = Su;

Pi.prototype.iexSsrStatus = function (t, {
  filter: e,
  format: o
} = {}) {
  return Su(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const bu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/system-event?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/system-event"
}));

exports.iexSystemEvent = bu;

Pi.prototype.iexSystemEvent = function (t, {
  filter: e,
  format: o
} = {}) {
  return bu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Eu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/trades?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/trades",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexTrades = Eu;

Pi.prototype.iexTrades = function (t, {
  filter: e,
  format: o
} = {}) {
  return Eu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Ru = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/trade-breaks?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/trade-breaks",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexTradeBreak = Ru;

Pi.prototype.iexTradeBreak = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ru(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const $u = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi(t ? {
  url: `deep/trading-status?symbols=${t}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "deep/trading-status",
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.iexTradingStatus = $u;

Pi.prototype.iexTradingStatus = function (t, {
  filter: e,
  format: o
} = {}) {
  return $u(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Au = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `hist?date=${Ce(t)}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "hist",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.iexHist = Au;

Pi.prototype.iexHist = function (t, {
  filter: e,
  format: o
} = {}) {
  return Au(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const wu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  if (Ae.indexOf(t) < 0) throw new ge("Uncrecognized tag");
  return xi({
    url: `stock/market/collection/${t}?collectionName=${e || ""}`,
    token: o,
    version: r,
    filter: n,
    format: i
  });
};

exports.collections = wu;

Pi.prototype.collections = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return wu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Iu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/today-earnings",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.earningsToday = Iu;

Pi.prototype.earningsToday = function ({
  filter: t,
  format: e
} = {}) {
  return Iu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Tu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/today-ipos",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.ipoToday = Tu;

Pi.prototype.ipoToday = function ({
  filter: t,
  format: e
} = {}) {
  return Tu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const xu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/upcoming-ipos",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.ipoUpcoming = xu;

Pi.prototype.ipoUpcoming = function ({
  filter: t,
  format: e
} = {}) {
  return xu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Ou = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => {
  if (t = t || "mostactive", $e.indexOf(t) < 0) throw new ge("Option not recognized");
  return xi({
    url: `stock/market/list/${t}`,
    token: e,
    version: o,
    filter: r,
    format: n
  });
};

exports.list = Ou;

Pi.prototype.list = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ou(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Lu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "market/",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.marketVolume = Lu;

Pi.prototype.marketVolume = function ({
  filter: t,
  format: e
} = {}) {
  return Lu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Mu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/ohlc",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.marketOhlc = Mu;

Pi.prototype.marketOhlc = function ({
  filter: t,
  format: e
} = {}) {
  return Mu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Pu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/previous",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.marketYesterday = Pu;

Pi.prototype.marketYesterday = function ({
  filter: t,
  format: e
} = {}) {
  return Pu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Uu = Pu;
exports.marketPrevious = Uu;
Pi.prototype.marketPrevious = Pi.prototype.marketYesterday;

const Nu = ({
  token: t,
  version: e,
  filter: o,
  format: r
} = {}) => xi({
  url: "stock/market/sector-performance",
  token: t,
  version: e,
  filter: o,
  format: r
});

exports.sectorPerformance = Nu;

Pi.prototype.sectorPerformance = function ({
  filter: t,
  format: e
} = {}) {
  return Nu({
    token: this._token,
    version: this._version,
    filter: t,
    format: e
  });
};

const Cu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `stock/market/short-interest/${Ce(t)}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "stock/market/short-interest",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.marketShortInterest = Cu;

Pi.prototype.marketShortInterest = function (t, {
  filter: e,
  format: o
} = {}) {
  return Cu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Du = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => t ? (je(t), xi({
  url: `stock/${qe(t)}/upcoming-events${e ? `?exactDate=${e}` : ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
})) : xi({
  url: "stock/market/upcoming-events" + (e ? `?exactDate=${e}` : ""),
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.upcomingEvents = Du;

Pi.prototype.upcomingEvents = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Du(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const ju = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => t ? (je(t), xi({
  url: `stock/${qe(t)}/upcoming-earnings${e ? `?exactDate=${e}` : ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
})) : xi({
  url: "stock/market/upcoming-earnings" + (e ? `?exactDate=${e}` : ""),
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.upcomingEarnings = ju;

Pi.prototype.upcomingEarnings = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return ju(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Fu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => t ? (je(t), xi({
  url: `stock/${qe(t)}/upcoming-dividends${e ? `?exactDate=${e}` : ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
})) : xi({
  url: "stock/market/upcoming-dividends" + (e ? `?exactDate=${e}` : ""),
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.upcomingDividends = Fu;

Pi.prototype.upcomingDividends = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Fu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Gu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => t ? (je(t), xi({
  url: `stock/${qe(t)}/upcoming-splits${e ? `?exactDate=${e}` : ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
})) : xi({
  url: "stock/market/upcoming-splits" + (e ? `?exactDate=${e}` : ""),
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.upcomingSplits = Gu;

Pi.prototype.upcomingSplits = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Gu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const qu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => t ? (je(t), xi({
  url: `stock/${qe(t)}/upcoming-ipos${e ? `?exactDate=${e}` : ""}`,
  token: o,
  version: r,
  filter: n,
  format: i
})) : xi({
  url: "stock/market/upcoming-ipos" + (e ? `?exactDate=${e}` : ""),
  token: o,
  version: r,
  filter: n,
  format: i
});

exports.upcomingIPOs = qu;

Pi.prototype.upcomingIPOs = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return qu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Hu = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/news/last/${e || 10}`,
  token: o,
  version: r,
  filter: n,
  format: i
}));

exports.news = Hu;

Pi.prototype.news = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return Hu(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const Bu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi({
  url: `stock/market/news/last/${t || 10}`,
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.marketNews = Bu;

Pi.prototype.marketNews = function (t, {
  filter: e,
  format: o
} = {}) {
  return Bu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Wu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/book`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.book = Wu;

Pi.prototype.book = function (t, {
  filter: e,
  format: o
} = {}) {
  return Wu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Yu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/delayed-quote`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.delayedQuote = Yu;

Pi.prototype.delayedQuote = function (t, {
  filter: e,
  format: o
} = {}) {
  return Yu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Xu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/largest-trades`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.largestTrades = Xu;

Pi.prototype.largestTrades = function (t, {
  filter: e,
  format: o
} = {}) {
  return Xu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Zu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/ohlc`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.ohlc = Zu;

Pi.prototype.ohlc = function (t, {
  filter: e,
  format: o
} = {}) {
  return Zu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Ku = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/previous`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.yesterday = Ku;

Pi.prototype.yesterday = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ku(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Vu = Ku;
exports.previous = Vu;
Pi.prototype.previous = Pi.prototype.yesterday;

const zu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/price`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.price = zu;

Pi.prototype.price = function (t, {
  filter: e,
  format: o
} = {}) {
  return zu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Qu = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/quote`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.quote = Qu;

Pi.prototype.quote = function (t, {
  filter: e,
  format: o
} = {}) {
  return Qu(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const Ju = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/effective-spread`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.spread = Ju;

Pi.prototype.spread = function (t, {
  filter: e,
  format: o
} = {}) {
  return Ju(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const tc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/volume-by-venue`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.volumeByVenue = tc;

Pi.prototype.volumeByVenue = function (t, {
  filter: e,
  format: o
} = {}) {
  return tc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ec = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  const {
    timeframe: s = "1m",
    date: a = "",
    exactDate: f = "",
    last: u = -1,
    closeOnly: c = !1,
    byDay: l = !1,
    simplify: p = !1,
    interval: m = -1,
    changeFromClose: v = !1,
    displayPercent: k = !1,
    sort: h = "",
    includeToday: y = !1
  } = e || {};
  je(t);

  let d = `stock/${qe(t)}/chart/${s}?`,
      _ = f || a;

  if (_ && (_ = Ce(_)), s && "1d" !== s && Ee.indexOf(s) < 0) throw new ge(`Timeframe not recognized ${s}`);
  const g = {};

  if (u > 0 && (g.chartLast = u), c && (g.chartCloseOnly = c), l && (g.chartByDay = l), p && (g.chartSimplify = p), m > 0 && (g.chartInterval = m), v && (g.changeFromClose = v), k && (g.displayPercent = k), f && (g.exactDate = f), h) {
    if ("asc" !== h.toLowerCase() && "desc" !== h.toLowerCase()) throw new ge(`Sort not recognized: ${h}`);
    g.sort = h.toLowerCase();
  }

  return y && (g.includeToday = y), _ ? (d = `stock/${qe(t)}/chart/date/${_}?`, Object.keys(g).length > 0 && (d += Object.entries(g).map(([t, e]) => `${t}=${e}`).join("&")), xi({
    url: d,
    token: o,
    version: r,
    filter: n,
    format: i
  })) : (Object.keys(g).length > 0 && (d += Object.entries(g).map(([t, e]) => `${t}=${e}`).join("&")), xi({
    url: d,
    token: o,
    version: r,
    filter: n,
    format: i
  }));
};

exports.chart = ec;

Pi.prototype.chart = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return ec(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const oc = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  const {
    date: s = "",
    exactDate: a = "",
    last: f = -1,
    IEXOnly: u = !1,
    reset: c = !1,
    simplify: l = !1,
    interval: p = -1,
    changeFromClose: m = !1,
    IEXWhenNull: v = !1
  } = e || {};
  je(t);
  let k = a || s;
  k && (k = Ce(k));
  const h = {};
  k && (h.exactDate = k), f > 0 && (h.chartLast = f), f > 0 && (h.chartLast = f), u && (h.chartIEXOnly = u), c && (h.chartReset = c), l && (h.chartSimplify = l), p > 0 && (h.chartInterval = p), m && (h.changeFromClose = m), v && (h.chartIEXWhenNull = v);
  let y = `stock/${qe(t)}/intraday-prices?`;
  return Object.keys(h).length > 0 && (y += Object.entries(h).map(([t, e]) => `${t}=${e}`).join("&")), xi({
    url: y,
    token: o,
    version: r,
    filter: n,
    format: i
  });
};

exports.intraday = oc;

Pi.prototype.intraday = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return oc(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const rc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/company`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.company = rc;

Pi.prototype.company = function (t, {
  filter: e,
  format: o
} = {}) {
  return rc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const nc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/insider-roster`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.insiderRoster = nc;

Pi.prototype.insiderRoster = function (t, {
  filter: e,
  format: o
} = {}) {
  return nc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ic = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/insider-summary`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.insiderSummary = ic;

Pi.prototype.insiderSummary = function (t, {
  filter: e,
  format: o
} = {}) {
  return ic(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const sc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/insider-transactions`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.insiderTransactions = sc;

Pi.prototype.insiderTransactions = function (t, {
  filter: e,
  format: o
} = {}) {
  return sc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const ac = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/logo`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.logo = ac;

Pi.prototype.logo = function (t, {
  filter: e,
  format: o
} = {}) {
  return ac(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const fc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/peers`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.peers = fc;

Pi.prototype.peers = function (t, {
  filter: e,
  format: o
} = {}) {
  return fc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const uc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/advanced-stats`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.advancedStats = uc;

Pi.prototype.advancedStats = function (t, {
  filter: e,
  format: o
} = {}) {
  return uc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const cc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/recommendation-trends`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.analystRecommendations = cc;

Pi.prototype.analystRecommendations = function (t, {
  filter: e,
  format: o
} = {}) {
  return cc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const lc = (t, e, o, {
  token: r,
  version: n,
  filter: i,
  format: s
} = {}) => (je(t), Fe(e || "quarter", o || 1), xi({
  url: `stock/${qe(t)}/estimates?period=${e || "quarter"}&last=${o || 1}`,
  token: r,
  version: n,
  filter: i,
  format: s
}));

exports.estimates = lc;

Pi.prototype.estimates = function (t, e, o, {
  filter: r,
  format: n
} = {}) {
  return lc(t, e, o, {
    token: this._token,
    version: this._version,
    filter: r,
    format: n
  });
};

const pc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/fund-ownership`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.fundOwnership = pc;

Pi.prototype.fundOwnership = function (t, {
  filter: e,
  format: o
} = {}) {
  return pc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const mc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/institutional-ownership`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.institutionalOwnership = mc;

Pi.prototype.institutionalOwnership = function (t, {
  filter: e,
  format: o
} = {}) {
  return mc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const vc = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => {
  if (je(t), e) {
    if (Ie.indexOf(e) < 0) throw new ge(`Stat must be in ${Ie}`);
    return xi({
      url: `stock/${qe(t)}/stats/${e}`,
      token: o,
      version: r,
      filter: n,
      format: i
    });
  }

  return xi({
    url: `stock/${qe(t)}/stats`,
    token: o,
    version: r,
    filter: n,
    format: i
  });
};

exports.keyStats = vc;

Pi.prototype.keyStats = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return vc(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const kc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => (je(t), xi({
  url: `stock/${qe(t)}/price-target`,
  token: e,
  version: o,
  filter: r,
  format: n
}));

exports.priceTarget = kc;

Pi.prototype.priceTarget = function (t, {
  filter: e,
  format: o
} = {}) {
  return kc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const hc = (t, e, o, r, {
  token: n,
  version: i,
  filter: s,
  format: a
} = {}) => {
  if (r = r || [], je(t), Me.indexOf(e) < 0) throw new ge("Indicator not recognized");
  if ("1d" !== (o || "1m") && Ee.indexOf(o || "1m") < 0) throw new ge("Range not recognized");
  let f = `stock/${t}/indicator/${e}?range=${o || "1m"}`;
  if (["abs", "acos", "ad", "add", "ao", "asin", "atan", "avgprice", "bop", "ceil", "cos", "cosh", "crossany", "crossover", "div", "emv", "exp", "floor", "ln", "log10", "marketfi", "medprice", "mul", "nvi", "obv", "pvi", "round", "sin", "sinh", "sqrt", "sub", "tan", "tanh", "todeg", "torad", "tr", "trunc", "typprice", "wad", "wcprice", "willr"].indexOf(e) >= 0 && r) throw ge("Indicator takes no arguments");

  if (["aroon", "aroonosc", "atr", "adx", "adxr", "cci", "cmo", "cvi", "decay", "dema", "di", "dm", "dpo", "dx", "edecay", "ema", "fisher", "fosc", "hma", "kama", "lag", "linreg", "linregintercept", "linregslope", "mass", "max", "md", "mfi", "min", "mom", "msw", "natr", "qstick", "roc", "rocr", "rsi", "sma", "stddev", "stderr", "stochrsi", "sum", "tema", "trima", "trix", "tsf", "var", "vhf", "volatility", "vwma", "wilders", "wma", "zlema"].indexOf(e) >= 0) {
    const [t, e, o, n] = r;
    if (e || o || n) throw ge("Indicator takes at most 1 argument");
    t && (f += `&input1=${t}`);
  }

  if (["adosc", "apo", "bbands", "kvo", "ppo", "psar", "vosc"].indexOf(e) >= 0) {
    const [t, e, o, n] = r;
    if (o || n) throw ge("Indicator takes at most 2 argument");
    t && (f += `&input1=${t}`), e && (f += `&input2=${e}`);
  }

  if (["macd", "stoch", "ultosc", "vidya"].indexOf(e) >= 0) {
    const [t, e, o, n] = r;
    if (n) throw ge("Indicator takes at most 3 argument");
    t && (f += `&input1=${t}`), e && (f += `&input2=${e}`), o && (f += `&input3=${o}`);
  }

  return xi({
    url: f,
    token: n,
    version: i,
    filter: s,
    format: a
  });
};

exports.technicals = hc;

Pi.prototype.technicals = function (t, e, o, r, {
  filter: n,
  format: i
} = {}) {
  return hc(t, e, o, r, {
    token: this._token,
    version: this._version,
    filter: n,
    format: i
  });
};

const yc = (t, {
  token: e,
  version: o,
  filter: r,
  format: n
} = {}) => xi(t ? {
  url: `stock/market/threshold-securities/${Ce(t)}`,
  token: e,
  version: o,
  filter: r,
  format: n
} : {
  url: "stock/market/threshold-securities",
  token: e,
  version: o,
  filter: r,
  format: n
});

exports.threshold = yc;

Pi.prototype.threshold = function (t, {
  filter: e,
  format: o
} = {}) {
  return yc(t, {
    token: this._token,
    version: this._version,
    filter: e,
    format: o
  });
};

const dc = (t, e, {
  token: o,
  version: r,
  filter: n,
  format: i
} = {}) => (je(t), xi(e ? {
  url: `stock/${qe(t)}/short-interest/${Ce(e)}`,
  token: o,
  version: r,
  filter: n,
  format: i
} : {
  url: `stock/${qe(t)}/short-interest`,
  token: o,
  version: r,
  filter: n,
  format: i
}));

exports.shortInterest = dc;

Pi.prototype.shortInterest = function (t, e, {
  filter: o,
  format: r
} = {}) {
  return dc(t, e, {
    token: this._token,
    version: this._version,
    filter: o,
    format: r
  });
};

const _c = "tradingstatus",
      gc = "auction",
      Sc = "op-halt-status",
      bc = "ssr-status",
      Ec = "security-event",
      Rc = "trade-breaks",
      $c = "trades",
      Ac = "book",
      wc = "system-event",
      Ic = "deep",
      Tc = (t, e, o, {
  token: r,
  version: n
} = {}) => {
  if (!t) throw new ge("method cannot be blank");
  return Ii(e ? "sandbox" === n ? _i(n, t, Ne(e), r) : mi(n, t, Ne(e), r) : "sandbox" === n ? Si(t, r) : ki(n, t, r), o);
},
      xc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("tops", t, e, o);

exports.topsSSE = xc;
exports._runSSE = Tc;
exports.ALL = Ic;
exports.SYSTEMEVENT = wc;
exports.BOOK = Ac;
exports.TRADES = $c;
exports.TRADEBREAK = Rc;
exports.SECURITYEVENT = Ec;
exports.SSR = bc;
exports.OPHALTSTATUS = Sc;
exports.AUCTION = gc;
exports.TRADINGSTATUS = _c;

Pi.prototype.topsSSE = function (t, e) {
  return xc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Oc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("last", t, e, {
  token: o,
  version: r
});

exports.lastSSE = Oc;

Pi.prototype.lastSSE = function (t, e) {
  return Oc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Lc = (t, e, o, {
  token: r,
  version: n
} = {}) => {
  if (!e) throw new ge("Must specify channels for deepSSE endpoints");
  return Ue(e).forEach(t => {
    if ([_c, gc, Sc, bc, Ec, Rc, $c, Ac, wc, Ic].indexOf(t) < 0) throw new ge(`Deep channel not recognized: ${t}`);
  }), e = Ne(e), Ii("sandbox" === n ? Ei(Ne(t), e, r) : yi(n, Ne(t), e, r), o);
};

exports.deepSSE = Lc;

Pi.prototype.deepSSE = function (t, e, o) {
  return Lc(t, e, o, {
    token: this._token,
    version: this._version
  });
};

const Mc = (t, e, {
  token: o,
  version: r
} = {}) => Ii("sandbox" === r ? Ei(Ne(t), "trades", o) : yi(r, Ne(t), "trades", o), e);

exports.tradesSSE = Mc;

Pi.prototype.tradesSSE = function (t, e) {
  return Mc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Pc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("auction", t, e, {
  token: o,
  version: r
});

exports.auctionSSE = Pc;

Pi.prototype.auctionSSE = function (t, e) {
  return Pc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Uc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("book", t, e, {
  token: o,
  version: r
});

exports.bookSSE = Uc;

Pi.prototype.bookSSE = function (t, e) {
  return Uc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Nc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("op-halt-status", t, e, {
  token: o,
  version: r
});

exports.opHaltStatusSSE = Nc;

Pi.prototype.opHaltStatusSSE = function (t, e) {
  return Nc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Cc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("official-price", t, e, {
  token: o,
  version: r
});

exports.officialPriceSSE = Cc;

Pi.prototype.officialPriceSSE = function (t, e) {
  return Cc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Dc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("security-event", t, e, {
  token: o,
  version: r
});

exports.securityEventSSE = Dc;

Pi.prototype.securityEventSSE = function (t, e) {
  return Dc(t, e, {
    token: this._token,
    version: this._version
  });
};

const jc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("ssr-status", t, e, {
  token: o,
  version: r
});

exports.ssrStatusSSE = jc;

Pi.prototype.ssrStatusSSE = function (t, e) {
  return jc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Fc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("system-event", t, e, {
  token: o,
  version: r
});

exports.systemEventSSE = Fc;

Pi.prototype.systemEventSSE = function (t, e) {
  return Fc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Gc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("trade-breaks", t, e, {
  token: o,
  version: r
});

exports.tradeBreaksSSE = Gc;

Pi.prototype.tradeBreaksSSE = function (t, e) {
  return Gc(t, e, {
    token: this._token,
    version: this._version
  });
};

const qc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("trading-status", t, e, {
  token: o,
  version: r
});

exports.tradingStatusSSE = qc;

Pi.prototype.tradingStatusSSE = function (t, e) {
  return qc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Hc = "cryptoBook",
      Bc = "cryptoEvents",
      Wc = "cryptoQuotes",
      Yc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("cryptoBook", t, e, {
  token: o,
  version: r
});

exports.cryptoBookSSE = Yc;
exports.CRYPTOQUOTES = Wc;
exports.CRYPTOEVENTS = Bc;
exports.CRYPTOBOOK = Hc;

Pi.prototype.cryptoBookSSE = function (t, e) {
  return Yc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Xc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("cryptoEvents", t, e, {
  token: o,
  version: r
});

exports.cryptoEventsSSE = Xc;

Pi.prototype.cryptoEventsSSE = function (t, e) {
  return Xc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Zc = (t, e, {
  token: o,
  version: r
} = {}) => Tc("cryptoQuotes", t, e, {
  token: o,
  version: r
});

exports.cryptoQuotesSSE = Zc;

Pi.prototype.cryptoQuotesSSE = function (t, e) {
  return Zc(t, e, {
    token: this._token,
    version: this._version
  });
};

const Kc = "forex",
      Vc = "forex1Second",
      zc = "forex5Second",
      Qc = "forex1Minute",
      Jc = (t, e, o = "forex", {
  token: r,
  version: n
} = {}) => Tc(o, t, e, {
  token: r,
  version: n
});

exports.fxSSE = Jc;
exports.FOREX1MINUTE = Qc;
exports.FOREX5SECOND = zc;
exports.FOREX1SECOND = Vc;
exports.FOREX = Kc;

Pi.prototype.fxSSE = function (t, e) {
  return Jc(t, e, {
    token: this._token,
    version: this._version
  });
};

const tl = (t, e, {
  token: o,
  version: r
} = {}) => Jc(t, e, "forex1Second", {
  token: o,
  version: r
});

exports.forex1SecondSSE = tl;

Pi.prototype.forex1SecondSSE = function (t, e) {
  return tl(t, e, {
    token: this._token,
    version: this._version
  });
};

const el = (t, e, {
  token: o,
  version: r
} = {}) => Jc(t, e, "forex5Second", {
  token: o,
  version: r
});

exports.forex5SecondSSE = el;

Pi.prototype.forex5SecondSSE = function (t, e) {
  return el(t, e, {
    token: this._token,
    version: this._version
  });
};

const ol = (t, e, {
  token: o,
  version: r
} = {}) => Jc(t, e, "forex1Minute", {
  token: o,
  version: r
});

exports.forex1MinuteSSE = ol;

Pi.prototype.forex1MinuteSSE = function (t, e) {
  return ol(t, e, {
    token: this._token,
    version: this._version
  });
};

const rl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("news-stream", t, e, {
  token: o,
  version: r
});

exports.newsSSE = rl;

Pi.prototype.newsSSE = function (t, e) {
  return rl(t, e, {
    token: this._token,
    version: this._version
  });
};

const nl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("sentiment", t, e, {
  token: o,
  version: r
});

exports.sentimentSSE = nl;

Pi.prototype.sentimentSSE = function (t, e) {
  return nl(t, e, {
    token: this._token,
    version: this._version
  });
};

const il = "stocksUSNoUTP",
      sl = "stocksUS",
      al = "stocksUS1Second",
      fl = "stocksUS5Second",
      ul = "stocksUS1Minute",
      cl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUSNoUTP", t, e, {
  token: o,
  version: r
});

exports.stocksUSNoUTPSSE = cl;
exports.STOCKSUS1MINUTE = ul;
exports.STOCKSUS5SECOND = fl;
exports.STOCKSUS1SECOND = al;
exports.STOCKSUS = sl;
exports.STOCKSUSNOUTP = il;

Pi.prototype.stocksUSNoUTPSSE = function (t, e) {
  return cl(t, e, {
    token: this._token,
    version: this._version
  });
};

const ll = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUS", t, e, {
  token: o,
  version: r
});

exports.stocksUSSSE = ll;

Pi.prototype.stocksUSSSE = function (t, e) {
  return ll(t, e, {
    token: this._token,
    version: this._version
  });
};

const pl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUS1Second", t, e, {
  token: o,
  version: r
});

exports.stocksUS1SecondSSE = pl;

Pi.prototype.stocksUS1SecondSSE = function (t, e) {
  return pl(t, e, {
    token: this._token,
    version: this._version
  });
};

const ml = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUSNoUTP1Second", t, e, {
  token: o,
  version: r
});

exports.stocksUSNoUTP1SecondSSE = ml;

Pi.prototype.stocksUSNoUTP1SecondSSE = function (t, e) {
  return ml(t, e, {
    token: this._token,
    version: this._version
  });
};

const vl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUS5Second", t, e, {
  token: o,
  version: r
});

exports.stocksUS5SecondSSE = vl;

Pi.prototype.stocksUS5SecondSSE = function (t, e) {
  return vl(t, e, {
    token: this._token,
    version: this._version
  });
};

const kl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUSNoUTP5Second", t, e, {
  token: o,
  version: r
});

exports.stocksUSNoUTP5SecondSSE = kl;

Pi.prototype.stocksUSNoUTP5SecondSSE = function (t, e) {
  return kl(t, e, {
    token: this._token,
    version: this._version
  });
};

const hl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUS1Minute", t, e, {
  token: o,
  version: r
});

exports.stocksUS1MinuteSSE = hl;

Pi.prototype.stocksUS1MinuteSSE = function (t, e) {
  return hl(t, e, {
    token: this._token,
    version: this._version
  });
};

const yl = (t, e, {
  token: o,
  version: r
} = {}) => Tc("stocksUSNoUTP1Minute", t, e, {
  token: o,
  version: r
});

exports.stocksUSNoUTP1MinuteSSE = yl;

Pi.prototype.stocksUSNoUTP1MinuteSSE = function (t, e) {
  return yl(t, e, {
    token: this._token,
    version: this._version
  });
};

const dl = t;
exports.VERSION = dl;

}).call(this)}).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
},{"_process":1}]},{},[2]);
